# 30s App Preview / Promo Storyboard

Scene 1 (0-4s): Title card — “Smart match insights” over blurred match background; quick pan of home screen.
Scene 2 (4-8s): Probability breakdown — animate W/D/L bars filling; label “See likely outcomes at a glance”.
Scene 3 (8-12s): Live updates — timeline ticks, a goal appears; badge bump animation.
Scene 4 (12-16s): Key stats — swipe through form, H2H, goals for/against.
Scene 5 (16-21s): Personalisation — pick favourite teams; dashboard filters update.
Scene 6 (21-25s): Premium — deeper analytics screen with rich charts.
Scene 7 (25-28s): Trust — About screen showing version/build, privacy note.
Scene 8 (28-30s): End card — “Download SoccerOracle” + badges.

Brand notes: Use clean light backgrounds, primary accent for highlights, and short overlays ≤30 chars.