
# Screenshot Device Matrix (Recommended)

These recommendations balance ASO impact and review reliability. Provide **at least one** full set per store; we recommend **two** sets for iOS and one for Android phones.

## iOS (App Store)

| Device (portrait) | Pixels (WxH) — examples | Count (min) | Notes |
|---|---|---:|---|
| iPhone 6.7" (e.g., 1290×2796 or 1284×2778) | 1290×2796, 1284×2778 | 5 | Primary set Apple reviewers expect today |
| iPhone 6.5" (e.g., 1242×2688 or 1284×2778) | 1242×2688, 1284×2778 | 5 | Optional, good coverage |
| iPad Pro 12.9" | 2048×2732 | 3–5 | Optional if you ship iPad UI |
| iPhone 5.5" | 1242×2208 | 3–5 | Legacy coverage (optional) |

**File rules (our linter):** place PNGs in `fastlane/screenshots/<locale>/` and name them with numeric prefixes `01_… .png` through `10_… .png` (e.g., `01_home.png`).

## Android (Google Play)

| Bucket | Directory | Pixels (portrait) | Count (min) | Notes |
|---|---|---|---:|---|
| Phone | `fastlane/metadata/android/<locale>/phoneScreenshots/` | 1080×1920–1440×3040 (or any 9:16 within Play rules) | 5 | Required set |
| 7-inch tablet | `…/sevenInchScreenshots/` | 1200×1920 | 0–3 | Optional |
| 10-inch tablet | `…/tenInchScreenshots/` | 1600×2560 | 0–3 | Optional |

**Play rules (summary):** PNG/JPG, each side **320–3840 px**, longest side ≤ **2×** shortest side.

---

## Locales
Start with `en-US` and `en-GB`. Add more locales using the same folder structure and naming.

## Lint Targets (defaults)
- iOS: **≥ 5** PNGs per locale, numeric prefixes `01…10`.
- Android Phone: **≥ 5** images per locale.

Use repo variables to customize (see `SETUP.md`). 
