# Store Listing Checklist

✅ App name, subtitle, promo text set (iOS)  
✅ Short/Full descriptions set (Play)  
✅ Keywords (ASO) added  
✅ Privacy/Support/Marketing URLs set  
✅ Screenshots plan & overlays prepared (8 portrait frames)  
✅ IAP products created (IDs match client)  
✅ Age rating review completed (no UGC, no gambling)  
✅ Data privacy forms filled (App Privacy / Data Safety)
✅ Localisation: en-US and en-GB included