const { withSentryConfig } = require("@sentry/nextjs");
const base = { output: 'standalone' };
const sentry = {
  org: process.env.SENTRY_ORG,
  project: process.env.SENTRY_PROJECT,
  silent: true
};
module.exports = withSentryConfig(base, sentry, {
  dryRun: !(process.env.SENTRY_AUTH_TOKEN && process.env.SENTRY_ORG && process.env.SENTRY_PROJECT),
  widenClientFileUpload: true
});
