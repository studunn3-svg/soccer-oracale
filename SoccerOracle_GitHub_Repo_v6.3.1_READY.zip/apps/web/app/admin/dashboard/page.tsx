'use client';
import useSWR from 'swr';
const fetcher = (url:string)=>fetch(url).then(r=>r.json());

export default function Dashboard() {
  const { data, error } = useSWR('/api/experiments/dashboard', fetcher, { refreshInterval: 5000 });

  if (!data) return <div className='card'>Loading…</div>;
  return (
    <div className='card'>
      <h2>Experiment Dashboard</h2>
      <div><strong>Total users assigned:</strong> {data.totalUsers}</div>
      <div style={{display:'flex',gap:12,marginTop:8}}>
        <div className='tile'>Variant A: {data.counts.A}</div>
        <div className='tile'>Variant B: {data.counts.B}</div>
        <div className='tile'>Control: {data.counts.control}</div>
      </div>
      <h3 style={{marginTop:12}}>Events</h3>
      <pre style={{whiteSpace:'pre-wrap'}}>{JSON.stringify(data.events,null,2)}</pre>
    </div>
  );
}
