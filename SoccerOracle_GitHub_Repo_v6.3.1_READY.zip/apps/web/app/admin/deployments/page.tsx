'use client';
import { useEffect, useMemo, useState } from 'react';

type ClientMeta = { ts:number, platform:string, releaseTag?:string, releaseVersion?:string, gitCommit?:string };

const GH_REPO = process.env.NEXT_PUBLIC_GITHUB_REPO || '';

export default function AdminDeployments(){
  const [rows, setRows] = useState<ClientMeta[]>([]);
  const [q, setQ] = useState('');
  useEffect(()=>{
    (async ()=>{
      const r = await fetch('/api/metrics/clients', { cache: 'no-store' });
      const j = await r.json();
      setRows(j||[]);
    })();
  },[]);

  const filtered = useMemo(()=>{
    if (!q) return rows;
    const s = q.toLowerCase();
    return rows.filter(r =>
      (r.platform||'').toLowerCase().includes(s) ||
      (r.releaseTag||'').toLowerCase().includes(s) ||
      (r.releaseVersion||'').toLowerCase().includes(s) ||
      (r.gitCommit||'').toLowerCase().includes(s)
    );
  }, [rows, q]);

  const commitUrl = (sha?:string) => {
    if (!sha) return null;
    if (!GH_REPO) return null;
    const base = GH_REPO.startsWith('http') ? GH_REPO : `https://github.com/${GH_REPO}`;
    return `${base.replace(/\.git$/, '')}/commit/${sha}`;
  };

  return (
    <main style={{padding:24}}>
      <h2>Admin → Deployments (client meta)</h2>
      <div style={{margin:'12px 0'}}>
        <input
          value={q}
          onChange={e=>setQ(e.target.value)}
          placeholder="Filter by platform, tag, version, commit…"
          style={{ padding: 8, width: '100%', maxWidth: 420, border:'1px solid #ccc', borderRadius:6 }}
        />
      </div>
      <table style={{ width:'100%', borderCollapse:'collapse' }}>
        <thead><tr>
          <th style={{textAlign:'left', padding:8, borderBottom:'1px solid #ccc'}}>When</th>
          <th style={{textAlign:'left', padding:8, borderBottom:'1px solid #ccc'}}>Platform</th>
          <th style={{textAlign:'left', padding:8, borderBottom:'1px solid #ccc'}}>Tag</th>
          <th style={{textAlign:'left', padding:8, borderBottom:'1px solid #ccc'}}>Version</th>
          <th style={{textAlign:'left', padding:8, borderBottom:'1px solid #ccc'}}>Commit</th>
        </tr></thead>
        <tbody>
          {filtered.map((r,i)=> {
            const url = commitUrl(r.gitCommit);
            const short = r.gitCommit?.slice(0,8) || '—';
            return (
              <tr key={i}>
                <td style={{padding:8}}>{new Date(r.ts).toLocaleString()}</td>
                <td style={{padding:8}}>{r.platform}</td>
                <td style={{padding:8}}>{r.releaseTag||'—'}</td>
                <td style={{padding:8}}>{r.releaseVersion||'—'}</td>
                <td style={{padding:8, fontFamily:'monospace'}}>
                  {url ? <a href={url} target="_blank" rel="noreferrer">{short}</a> : short}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </main>
  );
}
