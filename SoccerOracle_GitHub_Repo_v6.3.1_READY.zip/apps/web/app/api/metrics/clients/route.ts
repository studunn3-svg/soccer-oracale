export const dynamic = 'force-dynamic';

const BACKEND = process.env.NEXT_PUBLIC_API_BASE || process.env.BACKEND_API_BASE;

export async function GET() {
  if (!BACKEND) return Response.json([], { status:200 });
  try {
    const r = await fetch(`${BACKEND.replace(/\/$/,'')}/metrics/clients`, { cache: 'no-store' });
    const j = await r.json();
    return Response.json(j, { status: r.status });
  } catch (e:any) {
    return Response.json([], { status:200 });
  }
}
