export const dynamic = 'force-dynamic';
const BACKEND = process.env.NEXT_PUBLIC_API_BASE || process.env.BACKEND_API_BASE;

export async function POST(req: Request) {
  if (!BACKEND) return Response.json({ ok:false, error:'BACKEND not configured' }, { status:200 });
  try {
    const body = await req.json();
    const r = await fetch(`${BACKEND.replace(/\/$/,'')}/metrics/clients/ingest`, {
      method: 'POST',
      headers: { 'content-type':'application/json' },
      body: JSON.stringify(body),
      cache: 'no-store'
    });
    const j = await r.json().catch(()=>({}));
    return Response.json(j, { status: r.status });
  } catch (e:any) {
    return Response.json({ ok:false, error: e?.message || 'ingest failed' }, { status:200 });
  }
}
