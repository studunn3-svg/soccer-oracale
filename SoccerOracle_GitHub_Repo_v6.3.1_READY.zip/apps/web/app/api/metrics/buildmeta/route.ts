export const dynamic = 'force-dynamic';

export async function GET() {
  const j = {
    platform: 'web',
    releaseTag: process.env.NEXT_PUBLIC_RELEASE_TAG || process.env.RELEASE_TAG || null,
    releaseVersion: process.env.NEXT_PUBLIC_RELEASE_VERSION || process.env.npm_package_version || null,
    gitCommit: process.env.NEXT_PUBLIC_GIT_COMMIT || process.env.GITHUB_SHA || process.env.VERCEL_GIT_COMMIT_SHA || null
  };
  return Response.json(j);
}
