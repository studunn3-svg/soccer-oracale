import * as Sentry from "@sentry/nextjs";
const tracesSampleRate = Number(process.env.NEXT_PUBLIC_SENTRY_TRACES_SAMPLE_RATE ?? '0.2');
const profilesSampleRate = Number(process.env.NEXT_PUBLIC_SENTRY_PROFILES_SAMPLE_RATE ?? '0');
const apiRate = Number(process.env.NEXT_PUBLIC_SENTRY_TRACES_API_RATE ?? '0.05');
const tracesSampler = (ctx: any) => {
  try { const name = ctx?.transactionContext?.name || ''; if (name.includes('/api/')) return apiRate; } catch {}
  return tracesSampleRate;
};
if (process.env.NEXT_PUBLIC_SENTRY_DSN) {
  Sentry.init({ dsn: process.env.NEXT_PUBLIC_SENTRY_DSN, tracesSampleRate, tracesSampler, profilesSampleRate });
}
