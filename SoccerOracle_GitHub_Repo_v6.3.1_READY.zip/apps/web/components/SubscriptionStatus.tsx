import { useEffect, useState } from 'react';
export default function SubscriptionStatus(){
  const [status,setStatus] = useState<any>(null);
  useEffect(()=>{ (async()=>{
    try{ const r = await fetch('/api/subscription/status'); setStatus(await r.json()); }
    catch(e){ setStatus({ ok:false, error:'failed to fetch' }); }
  })(); },[]);
  return <pre style={{padding:12, background:'#fafafa', border:'1px solid #eee'}}>{JSON.stringify(status,null,2)}</pre>;
}
