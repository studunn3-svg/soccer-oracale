export default function Paywall(){
  return <div style={{padding:16, border:'1px solid #ddd', borderRadius:8}}>
    <h3>Paywall</h3>
    <p>Upgrade to unlock all predictions and analytics.</p>
  </div>;
}
