'use client';

import { useEffect, useState } from 'react';
import { Trophy, Star, Zap, Shield } from 'lucide-react';
import Link from 'next/link';

export function PersonalizedPaywall({ fallbackPeriod = 'monthly' }: { fallbackPeriod?: 'monthly'|'yearly' }) {
  const [prefs, setPrefs] = useState<any | null>(null);
  const [rec, setRec] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [variant, setVariant] = useState<'A'|'B'|'control'>('control');

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/me/prefs', { cache: 'no-store' });
        const json = res.ok ? await res.json() : null;
        setPrefs(json);
        // ask server for experiment assignment
        const assign = await (await fetch('/api/experiments/assign', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ userId: json?.userId })})).json();
        setVariant(assign.variant || 'control');
        const r = await (await fetch('/api/paywall/recommend', {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ userId: json?.userId, variant: assign.variant })
        })).json();
        setRec(r);
      } catch (e) {
        setRec({ period: fallbackPeriod, price: fallbackPeriod === 'monthly' ? 14.99 : 149.99, reason: 'Popular choice' });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const team = prefs?.favoriteTeam;
  const heroGradient = team ? `linear-gradient(135deg, ${team.primary}, ${team.secondary})` : 'linear-gradient(135deg,#08203a,#0b2f4a)';

  async function pickFavorite(teamId: string) {
    try {
      const res = await fetch('/api/me/favorite', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ userId: prefs?.userId, teamId }) });
      if (res.ok) {
        const updated = await res.json();
        setPrefs(prev => ({ ...prev, favoriteTeam: updated.favoriteTeam }));
        // analytics ping
        await fetch('/api/analytics/event', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ userId: prefs?.userId, event: 'favorite_team_set', props: { teamId } }) });
      }
    } catch (e) {
      console.error('fav err', e);
    }
  }

  // CTA click: record and navigate
  async function cta(period: 'monthly'|'yearly') {
    await fetch('/api/analytics/event', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ userId: prefs?.userId, event: 'paywall_cta_click', props: { period, variant } }) });
    location.assign(`/subscribe?period=${period}`);
  }

  return (
    <section className="personal-paywall card">
      <div className="hero" style={{ background: heroGradient }}>
        <div className="hero-left">
          {team ? (
            <>
              <div className="crest" style={{ backgroundImage: `url(${team.crestUrl || '/assets/team-placeholder.png'})` }} />
              <div className="hero-title">
                <h1>{variant === 'A' ? `Soccer Oracle — tailored for ${team.name}` : 'Soccer Oracle — unlock deeper football insights'}</h1>
                <div className="muted">{variant === 'A' ? `Updates & predictions for ${prefs?.favoriteLeague ?? 'your league'}` : 'Analytics, value finder & pro tools'}</div>
              </div>
            </>
          ) : (
            <div>
              <h1>Soccer Oracle — unlock deeper football insights</h1>
              <div className="muted">Analytics, value finder & pro tools</div>
            </div>
          )}
        </div>

        <div className="hero-right">
          <div className="recommended" style={{ borderColor: 'rgba(255,255,255,.12)' }}>
            <div className="kicker"><Trophy size={14}/> Recommended</div>
            <div className="price">
              <div className="amount">{loading ? '…' : `£${(rec?.price ?? 0).toFixed(2)}`}</div>
              <div className="period">{rec?.period === 'yearly' ? 'per year' : 'per month'}</div>
            </div>
            <div className="reason">{rec?.reason}</div>
            <div style={{marginTop:12}}>
              <button className="btn primary" onClick={()=>cta(rec?.period ?? 'monthly')}>Start {rec?.period === 'yearly' ? 'Yearly' : 'Monthly'}</button>
            </div>
          </div>
        </div>
      </div>

      <div className="features-row">
        <div className="feature">
          <div className="icon"><Star size={18}/></div>
          <div>
            <strong>Model-backed picks</strong>
            <div className="muted">xG + form + fatigue explained</div>
          </div>
        </div>
        <div className="feature">
          <div className="icon"><Zap size={18}/></div>
          <div>
            <strong>Value Finder</strong>
            <div className="muted">Shows expected edge vs bookies</div>
          </div>
        </div>
        <div className="feature">
          <div className="icon"><Shield size={18}/></div>
          <div>
            <strong>Secure checkout</strong>
            <div className="muted">Stripe & platform-native options</div>
          </div>
        </div>
      </div>

      <div className="personal-cta">
        <div className="note muted">
          {prefs?.favoriteTeam ? `Because you follow ${prefs.favoriteTeam.name}, we surface match alerts and team form.` : 'Sign in and we’ll tailor this paywall for you.'}
        </div>
        <div style={{display:'flex',gap:8, marginTop:8}}>
          <Link href="/features" className="btn ghost">See all features</Link>
          <Link href="/demo" className="btn">Explore demo</Link>
        </div>
        <div style={{marginTop:12}}>
          <strong>Pick favorite team (demo)</strong>
          <div style={{display:'flex',gap:8,marginTop:8}}>
            <button className="btn" onClick={()=>pickFavorite('arsenal')}>Arsenal</button>
            <button className="btn" onClick={()=>pickFavorite('man_city')}>Man City</button>
            <button className="btn" onClick={()=>pickFavorite('chelsea')}>Chelsea</button>
          </div>
        </div>
      </div>
    </section>
  );
}
