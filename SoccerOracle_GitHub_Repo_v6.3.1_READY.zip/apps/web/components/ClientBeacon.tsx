'use client';
import { useEffect } from 'react';

export default function ClientBeacon(){
  useEffect(()=>{
    (async ()=>{
      try{
        const metaRes = await fetch('/api/metrics/buildmeta', { cache:'no-store' });
        const meta = await metaRes.json().catch(()=>({}));
        const payload = {
          ts: Date.now(),
          platform: 'web',
          releaseTag: meta.releaseTag || process.env.NEXT_PUBLIC_RELEASE_TAG || null,
          releaseVersion: meta.releaseVersion || process.env.npm_package_version || null,
          gitCommit: meta.gitCommit || process.env.NEXT_PUBLIC_GIT_COMMIT || null,
        };
        await fetch('/api/metrics/clients/ingest', {
          method: 'POST',
          headers: { 'content-type':'application/json' },
          body: JSON.stringify(payload)
        });
      }catch(e){ /* swallow */ }
    })();
  }, []);
  return null;
}
