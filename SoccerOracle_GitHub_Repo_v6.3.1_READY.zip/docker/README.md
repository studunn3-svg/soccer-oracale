# Docker Compose (backend + web + nginx)

## Quick start
```bash
cd docker
docker compose up --build
# Web:   http://localhost/
# API:   http://localhost/api/health
```

- Uses SQLite for Prisma by default (volume `backend_data` stores the DB at `backend/backend/prisma`).
- Reverse proxy with nginx (routes `/api/*` to backend and everything else to web).

### Env files
- `docker/.env.backend` — backend env (ports, Stripe/IAP keys, etc.)
- `docker/.env.web` — web env (NEXT_PUBLIC_API_BASE is auto-set to backend container)

### Notes
- For production HTTPS, put nginx behind a TLS terminator (or use nginx with certs).
- If you later move to Postgres, update Prisma datasource and add a `db` service here.
