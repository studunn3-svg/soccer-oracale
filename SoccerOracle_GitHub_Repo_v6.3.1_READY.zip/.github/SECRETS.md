# GitHub Secrets (required/recommended)

## Expo / EAS
- EXPO_TOKEN
- EXPO_PUBLIC_API_BASE (production API base)
- WEB_STAGING_API_BASE (staging API base)

## Sentry
- SENTRY_AUTH_TOKEN
- SENTRY_ORG
- SENTRY_PROJECT
- NEXT_PUBLIC_SENTRY_DSN
- (optional) EXPO_PUBLIC_SENTRY_TRACES_SAMPLE_RATE (default 0.2)
- (optional) EXPO_PUBLIC_SENTRY_PROFILES_SAMPLE_RATE (default 0)

## GitHub Links
- NEXT_PUBLIC_GITHUB_REPO (e.g., org/repo)

## Android Submit
- GOOGLE_PLAY_JSON (full JSON of Play Console service account)

Notes:
- The Release job also uses EXPO_TOKEN to download EAS artifacts.
- Strict provenance checks will FAIL the release if tag version or commit do not match the EAS builds.

- SLACK_WEBHOOK_URL (optional, for Slack notifications)
- DISCORD_WEBHOOK_URL (optional, for Discord notifications)

- EAS_ACCOUNT (optional; Expo account/owner for build links)
- EAS_PROJECT (optional; Expo project slug for build links)

- EAS_SUMMARY_ONLY_FINISHED (repository variable; 'true' to show only finished items; default true)
- EAS_SUMMARY_ROWS (repository variable; max rows per table/list; default 5)
- EAS_SUMMARY_ENABLE_TABLES (repository variable; 'true' to render tables; 'false' for bullet lists; default true)

- EAS_REQUIRE_SUBMISSIONS_FINISHED (repository variable; 'any' or 'both'/'all' or 'true' (alias any); default off)

- EAS_REQUIRE_BUILDS_FINISHED (repository variable; 'any' or 'both'/'all' or 'true' (alias any); default off)
- EAS_FAIL_ON_BUILD_FAILURES (repository variable; 'true' to fail on any Failed/Errored/Canceled builds; default off)
- EAS_FAIL_ON_SUBMISSION_ERRORS (repository variable; 'true' to fail if any submission has error/errored/failed; default off)

- The first tag that triggers a Release will auto-append `SETUP.md` to the Release body (uses default `GITHUB_TOKEN`).

- On the **first release of each major** (e.g., first `v7.x`), `SETUP.md` is automatically appended to the Release body.

- API_HEALTH_URL_STAGING (repository variable; e.g., https://staging.api.yourdomain.com/health)
- API_HEALTH_URL_PRODUCTION (repository variable; e.g., https://api.yourdomain.com/health)
- REQUIRE_HEALTH_OK (repository variable; set to 'true' to enforce health checks; default off)
- EXPO_PUBLIC_SENTRY_TRACES_SAMPLE_RATE (optional; 0.0–1.0)
- EXPO_PUBLIC_SENTRY_PROFILES_SAMPLE_RATE (optional; 0.0–1.0)

- SENTRY_MAX_TRACES_RATE_PROD (repository variable; default 0.1)
- SENTRY_MAX_PROFILES_RATE_PROD (repository variable; default 0.05)
- SENTRY_MAX_TRACES_RATE_STAGING (repository variable; default 0.5)
- SENTRY_MAX_PROFILES_RATE_STAGING (repository variable; default 0.2)

- SENTRY_REQUIRE_DSN_PROD (repository variable; set 'true' to require DSN in production env files/eas.json; default true)
- SENTRY_REQUIRE_DSN_STAGING (repository variable; set 'true' to require DSN in staging; default false)

- SENTRY_GUARD_MODE (repository variable; 'events' or 'sessions'; default 'events')
- SENTRY_ERROR_RATE_WINDOW_MIN (repository variable; window in minutes; default 30)
- SENTRY_ERROR_RATE_MAX (repository variable; max error rate for 'events' mode; default 0.05)
- SENTRY_ERRORS_MAX (repository variable; absolute error cap when no transactions seen; default 50)
- SENTRY_MIN_CRASH_FREE_SESSIONS (repository variable; minimum crash-free rate for 'sessions' mode; default 0.98)

- On Sentry guard failure, the workflow **creates/updates a draft GitHub Release** for the current tag and appends a failure note with links to Sentry Errors/Performance.
- SENTRY_GUARD_OVERRIDE (repository variable; set 'true' to bypass the error budget guard for a single run — an OVERRIDDEN note will be attached to the Release)
- Manual run supports `override_guard` input under **Actions → Release → Run workflow** (appends an OVERRIDDEN note).

- ENTITLEMENTS_BACKEND (repository variable or backend env; 'file' (default) or 'sqlite')
- ENTITLEMENTS_FILE_PATH (backend env; default ./tmp_entitlements.json)
- ENTITLEMENTS_SQLITE_PATH (backend env; default ./tmp_entitlements.sqlite)

- APP_STORE_CONNECT_API_KEY_JSON (secret; JSON for App Store Connect API key)
- IOS_APP_IDENTIFIER (variable; e.g., com.yourcompany.socceroracle)
- APP_STORE_APPLE_ID (variable; numeric Apple app ID, e.g., 1234567890)
- ANDROID_PACKAGE_NAME (variable; e.g., com.yourcompany.socceroracle)
- RUN_FASTLANE_DELIVER (variable; 'true' to upload iOS metadata)
- RUN_FASTLANE_SUPPLY (variable; 'true' to upload Android metadata)
- PLAY_TRACK (variable; default 'alpha', can be 'internal', 'alpha', 'beta', or 'production')

- RUN_FASTLANE_DELIVER_SCREENSHOTS (variable; 'true' to upload iOS screenshots via deliver)
- RUN_FASTLANE_SUPPLY_SCREENSHOTS (variable; 'true' to upload Android screenshots via supply)
- IOS_SCREENSHOTS_PATH (variable; path to iOS screenshots; default fastlane/screenshots)
- ANDROID_SCREENSHOTS_PATH (variable; path to Android metadata/screenshots; default fastlane/metadata/android)
- DOWNLOAD_SCREENSHOTS_ARTIFACT (variable; 'true' to download screenshots artifact before upload)
- STORE_SCREENSHOTS_ARTIFACT_NAME (variable; artifact name to download; e.g., store-screenshots)

- LOCALES (variable; comma-separated; default 'en-US,en-GB')
- IOS_SCREENSHOTS_MIN_COUNT (variable; default '5')
- ANDROID_PHONE_MIN_COUNT (variable; default '5')
- CHECK_DIMS (variable; 'true' to enforce dimension checks; default 'true')
- Filename rule: numeric prefixes '01_'..'10_' enforced by linter

- RUN_SCREENSHOT_AUTONAME (variable; 'true' to auto-map raw screenshots to 01_… names using overlays CSV)
- Place raw files under `fastlane/_raw/ios/<locale>/` and `fastlane/_raw/android/<locale>/phone/` (or put them directly in final folders; the tool will rename in-place if needed).

- RUN_RENDER_OVERLAYS (variable; 'true' to render overlay text onto screenshots before naming/lint/upload)
- PANEL_HEIGHT_PCT (variable; default 22)
- OVERLAY_PADDING (variable; default 48)
- HEADLINE_SIZE_PCT (variable; default 4.2)
- SUBHEAD_SIZE_PCT (variable; default 2.6)
- OVERLAY_FONT (variable; default 'Arial'; must be available on runner)
- OVERLAY_COLOR_HEAD (variable; default 'white')
- OVERLAY_COLOR_SUB (variable; default '#f0f0f0')
- OVERLAY_PANEL_COLOR (variable; default '#000000AA')
