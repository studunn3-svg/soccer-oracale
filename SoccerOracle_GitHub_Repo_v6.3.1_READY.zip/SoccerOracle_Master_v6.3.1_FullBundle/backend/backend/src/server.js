
app.use('/api/me', require('./routes/me'));
app.use('/api/me', require('./routes/favorites'));
app.use('/api/experiments', require('./routes/experiments'));
app.use('/api/analytics', require('./routes/analytics'));
app.use('/api/experiments/dashboard', require('./routes/dashboard'));

// IAP + Metrics routes
import iapApple from './routes/iap/apple.js';
import iapGoogle from './routes/iap/google.js';
import metricsClients from './routes/metrics/clients.js';
app.use('/iap/apple', iapApple);
app.use('/iap/google', iapGoogle);
app.use('/metrics/clients', metricsClients);


/** Health endpoint for CI checks */
app.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'backend',
    version: (pkg && pkg.version) || null,
    commit: process.env.GIT_COMMIT || process.env.GITHUB_SHA || null,
    uptime: process.uptime(),
    ts: Date.now()
  });
});

import adminEntitlements from './routes/metrics/admin_entitlements.js';
app.use('/admin/entitlements', adminEntitlements);
