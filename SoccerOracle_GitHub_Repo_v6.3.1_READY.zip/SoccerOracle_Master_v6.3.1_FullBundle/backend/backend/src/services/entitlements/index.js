/**
 * Tiny entitlements service with pluggable storage.
 * Default: file JSON store (no native deps).
 * Optional: sqlite (set ENTITLEMENTS_BACKEND=sqlite).
 */
import fs from 'fs';
import path from 'path';

const MODE = (process.env.ENTITLEMENTS_BACKEND || 'file').toLowerCase();
const FILE_PATH = process.env.ENTITLEMENTS_FILE_PATH || path.join(process.cwd(), 'tmp_entitlements.json');
const SQLITE_PATH = process.env.ENTITLEMENTS_SQLITE_PATH || path.join(process.cwd(), 'tmp_entitlements.sqlite');

function now(){ return Date.now(); }
function safeJsonRead(p){
  try{ return JSON.parse(fs.readFileSync(p,'utf8')); } catch(_){ return []; }
}
function safeJsonWrite(p, v){
  try{ fs.writeFileSync(p, JSON.stringify(v, null, 2)); } catch(e){ /* ignore */ }
}

class FileStore {
  constructor(file=FILE_PATH){ this.file = file; }
  list(){ return safeJsonRead(this.file); }
  put(row){
    const arr = this.list();
    const idx = arr.findIndex(r=> r.platform===row.platform && r.productId===row.productId && (r.transactionId===row.transactionId || r.purchaseToken===row.purchaseToken));
    if(idx>=0){ arr[idx] = { ...arr[idx], ...row, updatedAt: now() }; }
    else { arr.unshift({ ...row, createdAt: now(), updatedAt: now() }); }
    safeJsonWrite(this.file, arr.slice(0, 5000));
  }
  byToken({ platform, transactionId, purchaseToken }){
    const arr = this.list();
    return arr.find(r=> r.platform===platform && (r.transactionId===transactionId || r.purchaseToken===purchaseToken));
  }
  listByUser(userId){
    const arr = this.list();
    return arr.filter(r=> r.userId===userId);
  }
}

class SqliteStore {
  constructor(dbPath=SQLITE_PATH){
    try {
      const sqlite3 = require('sqlite3').verbose();
      this.db = new sqlite3.Database(dbPath);
      this.db.serialize(()=>{
        this.db.run(`CREATE TABLE IF NOT EXISTS entitlements (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          userId TEXT,
          platform TEXT,
          productId TEXT,
          status TEXT,
          expiryMs INTEGER,
          transactionId TEXT,
          purchaseToken TEXT,
          raw JSON,
          createdAt INTEGER,
          updatedAt INTEGER
        )`);
        this.db.run(`CREATE INDEX IF NOT EXISTS idx_ent_token ON entitlements(platform, transactionId, purchaseToken)`);
        this.db.run(`CREATE INDEX IF NOT EXISTS idx_ent_user ON entitlements(userId)`);
      });
    } catch (e){
      // fallback to file store if sqlite not available
      console.warn('SQLite not available, falling back to file store:', e.message);
      this.db = null;
      this.fallback = new FileStore();
    }
  }
  list(){
    if(!this.db) return this.fallback.list();
    return new Promise((resolve,reject)=>{
      this.db.all("SELECT * FROM entitlements ORDER BY id DESC LIMIT 5000", (err,rows)=> err?reject(err):resolve(rows||[]));
    });
  }
  put(row){
    if(!this.db) return this.fallback.put(row);
    const t = now();
    const raw = JSON.stringify(row.raw || null);
    const sel = "SELECT id FROM entitlements WHERE platform=? AND (transactionId=? OR purchaseToken=?) LIMIT 1";
    this.db.get(sel, [row.platform, row.transactionId||null, row.purchaseToken||null], (err, found)=>{
      if (found){
        const upd = `UPDATE entitlements SET userId=?, productId=?, status=?, expiryMs=?, raw=?, updatedAt=? WHERE id=?`;
        this.db.run(upd, [row.userId||null, row.productId||null, row.status||null, row.expiryMs||null, raw, t, found.id]);
      } else {
        const ins = `INSERT INTO entitlements(userId,platform,productId,status,expiryMs,transactionId,purchaseToken,raw,createdAt,updatedAt) VALUES(?,?,?,?,?,?,?,?,?,?)`;
        this.db.run(ins, [row.userId||null, row.platform, row.productId||null, row.status||null, row.expiryMs||null, row.transactionId||null, row.purchaseToken||null, raw, t, t]);
      }
    });
  }
  byToken({ platform, transactionId, purchaseToken }){
    if(!this.db) return this.fallback.byToken({ platform, transactionId, purchaseToken });
    return new Promise((resolve,reject)=>{
      this.db.get("SELECT * FROM entitlements WHERE platform=? AND (transactionId=? OR purchaseToken=?) LIMIT 1",
        [platform, transactionId||null, purchaseToken||null], (err,row)=> err?reject(err):resolve(row||null));
    });
  }
  listByUser(userId){
    if(!this.db) return this.fallback.listByUser(userId);
    return new Promise((resolve,reject)=>{
      this.db.all("SELECT * FROM entitlements WHERE userId=? ORDER BY updatedAt DESC LIMIT 500", [userId], (err,rows)=> err?reject(err):resolve(rows||[]));
    });
  }
}

const store = (MODE === 'sqlite') ? new SqliteStore(SQLITE_PATH) : new FileStore(FILE_PATH);

export const Entitlements = {
  async upsert({ userId, platform, productId, status, expiryMs, transactionId, purchaseToken, raw }){
    store.put({ userId, platform, productId, status, expiryMs, transactionId, purchaseToken, raw });
    return { ok:true };
  },
  async getByUser(userId){
    return await store.listByUser(userId);
  },
  async getByToken({ platform, transactionId, purchaseToken }){
    return await store.byToken({ platform, transactionId, purchaseToken });
  },
  async listAll(){ return await store.list(); }
};
