import { google } from 'googleapis';

function getJWT(){
  try{
    if (process.env.GOOGLE_PLAY_JSON){
      const creds = JSON.parse(process.env.GOOGLE_PLAY_JSON);
      return new google.auth.JWT(creds.client_email, null, creds.private_key, ['https://www.googleapis.com/auth/androidpublisher']);
    }
    // Fallback to ADC if GOOGLE_APPLICATION_CREDENTIALS is set
    return new google.auth.GoogleAuth({ scopes:['https://www.googleapis.com/auth/androidpublisher'] });
  }catch(e){
    return null;
  }
}

export async function validatePurchase({ packageName, productId, purchaseToken, isSubscription }){
  if (!packageName || !productId || !purchaseToken){
    return { ok:false, error:'packageName, productId, purchaseToken required' };
  }
  // Use googleapis if credentials are available; otherwise stub-success with a warning.
  try{
    const auth = getJWT();
    if (!auth){ return { ok:true, note:'validated (no creds present, stubbed)', stub:true }; }
    const androidpublisher = google.androidpublisher({ version:'v3', auth });
    if (isSubscription){
      const res = await androidpublisher.purchases.subscriptions.get({ packageName, subscriptionId: productId, token: purchaseToken });
      return { ok:true, kind:'subscription', status: res.data.paymentState ?? res.data.purchaseState ?? null, expiryTimeMillis: res.data.expiryTimeMillis ?? null, raw: res.data };
    }else{
      const res = await androidpublisher.purchases.products.get({ packageName, productId, token: purchaseToken });
      return { ok:true, kind:'inapp', purchaseState: res.data.purchaseState ?? null, consumptionState: res.data.consumptionState ?? null, purchaseTimeMillis: res.data.purchaseTimeMillis ?? null, raw: res.data };
    }
  }catch(e){
    return { ok:false, error: e.message || String(e) };
  }
}
