import * as jose from 'jose';

async function getJWKS(){
  const url = process.env.APPLE_IAP_JWKS_URL; // e.g. https://YOUR-CACHE/apple-iap-jwks.json
  if (!url) return null;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`JWKS fetch failed: ${res.status}`);
  const jwks = await res.json();
  return jose.createLocalJWKSet(jwks);
}

export async function validateReceipt({ signedTransactionInfo, transactionId }){
  // Prefer signedTransactionInfo (StoreKit 2 JWS from device). If provided and JWKS URL set, verify signature.
  try{
    if (signedTransactionInfo){
      const jwks = await getJWKS();
      if (jwks){
        const { payload, protectedHeader } = await jose.jwtVerify(signedTransactionInfo, jwks, { algorithms:['ES256'] });
        return { ok:true, verified:true, header: protectedHeader, payload };
      }else{
        // No JWKS provided: accept but mark unverified
        return { ok:true, verified:false, note:'No APPLE_IAP_JWKS_URL configured; signature not verified' };
      }
    }
    // Fallback: if transactionId provided, accept and mark actionable (server should call App Store Server API)
    if (transactionId){
      return { ok:true, verified:false, note:'transactionId received; implement server-to-server lookup with App Store Server API', transactionId };
    }
    return { ok:false, error:'signedTransactionInfo or transactionId required' };
  }catch(e){
    return { ok:false, error: e.message || String(e) };
  }
}
