const { prisma } = require('./db');

async function upsertEntitlement({ userId, platform, productId, originalTxId, purchaseToken, autoRenewing, expiryTimeMs, status }) {
  if (!userId) throw new Error('userId required');
  await prisma.user.upsert({
    where: { id: userId },
    create: { id: userId },
    update: {}
  });
  // Find existing by user + platform + product
  const existing = await prisma.entitlement.findFirst({
    where: { userId, platform, productId }
  });
  if (existing) {
    return prisma.entitlement.update({
      where: { id: existing.id },
      data: { originalTxId, purchaseToken, autoRenewing: !!autoRenewing, expiryTimeMs: BigInt(expiryTimeMs || 0), status }
    });
  } else {
    return prisma.entitlement.create({
      data: { userId, platform, productId, originalTxId, purchaseToken, autoRenewing: !!autoRenewing, expiryTimeMs: BigInt(expiryTimeMs || 0), status }
    });
  }
}

async function getActiveEntitlement({ userId }) {
  const now = BigInt(Date.now());
  const ent = await prisma.entitlement.findFirst({
    where: { userId, expiryTimeMs: { gt: now } },
    orderBy: { expiryTimeMs: 'desc' }
  });
  return ent;
}

module.exports = { upsertEntitlement, getActiveEntitlement };
