const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const DB = path.join(__dirname, '..', 'lib', 'simple_db.json');

router.get('/', (req,res)=>{
  try{
    const raw = JSON.parse(fs.readFileSync(DB,'utf8'));
    const counts = { A:0, B:0, control:0 };
    Object.values(raw.assignments||{}).forEach(v=>{ counts[v]= (counts[v]||0) + 1 });
    const eventsSummary = {};
    Object.entries(raw.events||{}).forEach(([user,arr])=>{
      arr.forEach(e=>{ eventsSummary[e.event] = (eventsSummary[e.event]||0) + 1 });
    });
    res.json({ counts, events: eventsSummary, favorites: raw.favorites||{}, totalUsers: Object.keys(raw.assignments||{}).length });
  }catch(e){ console.error(e); res.status(500).json({ error:'failed' }) }
});

module.exports = router;
