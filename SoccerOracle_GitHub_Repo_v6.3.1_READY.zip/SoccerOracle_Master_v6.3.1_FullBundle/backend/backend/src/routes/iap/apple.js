import express from 'express';
import { validateReceipt } from '../../services/iap/apple.js';
import * as jose from 'jose';
import { Entitlements } from '../../services/entitlements/index.js';

const router = express.Router();

// Client validation (StoreKit 2 signedTransactionInfo or transactionId)
router.post('/validate', async (req, res) => {
  const result = await validateReceipt(req.body || {});
  res.status(result.ok?200:400).json(result);
});

// App Store Server Notifications v2
router.post('/assn', express.text({ type: '*/*' }), async (req, res) => {
  // Apple sends a JWS (string). Verify if APPLE_IAP_JWKS_URL configured.
  try{
    const jws = (req.body || '').trim();
    if (!jws) return res.status(400).json({ ok:false, error:'empty body' });
    const url = process.env.APPLE_IAP_JWKS_URL;
    if (!url){
      // Accept but mark unverified; log for later processing
      try { await Entitlements.upsert({ userId:null, platform:'ios', productId:null, status:'unknown', expiryMs:null, transactionId:null, purchaseToken:null, raw:{ note:'no_jwks' } }); } catch(_){}
      return res.json({ ok:true, verified:false, note:'No APPLE_IAP_JWKS_URL configured' });
    }
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`JWKS fetch failed: ${resp.status}`);
    const jwks = await resp.json();
    const jwkSet = jose.createLocalJWKSet(jwks);
    const { payload, protectedHeader } = await jose.jwtVerify(jws, jwkSet, { algorithms:['ES256'] });
    // TODO: persist payload.signedPayload.notificationType etc.
    try {
        const payloadObj = payload || {};
        const signedPayload = payloadObj.signedPayload || {};
        const data = (typeof signedPayload === 'string') ? JSON.parse(Buffer.from(signedPayload.split('.')[1] || '', 'base64').toString('utf8')) : signedPayload;
        const txn = data?.data || data;
        await Entitlements.upsert({ userId: null, platform: 'ios', productId: txn?.productId, status: txn?.status || 'active', expiryMs: txn?.expiresDate? Number(txn.expiresDate): null, transactionId: txn?.transactionId, purchaseToken: null, raw: payloadObj });
      } catch(_) { /* ignore persist errors */ }
      res.json({ ok:true, verified:true, header: protectedHeader, payload });
  }catch(e){
    res.status(400).json({ ok:false, error: e.message || String(e) });
  }
});

export default router;
