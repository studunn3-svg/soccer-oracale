import express from 'express';
import { validatePurchase } from '../../services/iap/google.js';
import { Entitlements } from '../../services/entitlements/index.js';
const router = express.Router();

// Client validation (in-app purchases / subscriptions)
router.post('/validate', async (req, res) => {
  const { packageName, productId, purchaseToken, isSubscription } = req.body || {};
  const result = await validatePurchase({ packageName, productId, purchaseToken, isSubscription });
  res.status(result.ok?200:400).json(result);
});

// Real-time developer notifications (Pub/Sub push)
router.post('/rtdn', express.json({ type:'application/json' }), async (req, res) => {
  try{
    const msg = (req.body && req.body.message) || {};
    const dataB64 = msg.data;
    if (!dataB64){ return res.status(400).json({ ok:false, error:'missing message.data' }); }
    const json = JSON.parse(Buffer.from(dataB64, 'base64').toString('utf8'));
      try {
        const n = json.subscriptionNotification || json.oneTimeProductNotification || {};
        const productId = n.subscriptionId || n.sku || undefined;
        const purchaseToken = n.purchaseToken || undefined;
        const notificationType = n.notificationType || json.notificationType || 'unknown';
        const status = (String(notificationType).match(/CANCEL|REVOKE|REFUND|CHARGEBACK/i)) ? 'revoked' : 'active';
        await Entitlements.upsert({ userId: null, platform: 'android', productId, status, expiryMs: null, transactionId: null, purchaseToken, raw: json });
      } catch (_) { /* ignore persist errors */ }
    // json.subscriptionNotification / json.oneTimeProductNotification / json.testNotification
    // TODO: update entitlements based on notificationType & purchaseToken
    res.json({ ok:true, kind: Object.keys(json)[0] || 'unknown' });
  }catch(e){
    res.status(400).json({ ok:false, error: e.message || String(e) });
  }
});

export default router;
