import express from 'express';
import { Entitlements } from '../../services/entitlements/index.js';
const router = express.Router();

router.get('/', async (_req, res)=>{
  try{
    const rows = await Entitlements.listAll();
    res.json(rows);
  }catch(e){
    res.status(500).json({ ok:false, error: e.message || String(e) });
  }
});

export default router;
