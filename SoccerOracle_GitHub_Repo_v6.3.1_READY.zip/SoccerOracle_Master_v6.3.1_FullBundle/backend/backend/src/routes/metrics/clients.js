import express from 'express';
import fs from 'fs';
import path from 'path';

const router = express.Router();
const DATA = path.join(process.cwd(), 'tmp_metrics_clients.json');
const TTL_MS = 1000 * 60 * 60 * 24 * 3; // 3 days

function load(){
  try{
    const arr = JSON.parse(fs.readFileSync(DATA, 'utf8'));
    return Array.isArray(arr) ? arr.filter(x => Date.now() - (x.ts||0) < TTL_MS) : [];
  }catch(e){ return []; }
}
function save(arr){ try{ fs.writeFileSync(DATA, JSON.stringify(arr, null, 2)); }catch(e){} }

// GET: list recent client beacons
router.get('/', (_req, res)=>{
  return res.json(load());
});

// POST: ingest a client beacon { platform, releaseTag, releaseVersion, gitCommit }
router.post('/ingest', express.json(), (req, res)=>{
  const { platform, releaseTag, releaseVersion, gitCommit } = req.body || {};
  if (!platform) return res.status(400).json({ ok:false, error:'platform required' });
  const row = { ts: Date.now(), platform, releaseTag, releaseVersion, gitCommit };
  const arr = load(); arr.unshift(row); save(arr.slice(0, 1000));
  return res.json({ ok:true });
});

export default router;
