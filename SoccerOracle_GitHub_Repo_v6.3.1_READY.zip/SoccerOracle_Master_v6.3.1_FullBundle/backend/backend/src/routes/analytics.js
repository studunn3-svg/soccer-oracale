const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const DB = path.join(__dirname, '..', 'lib', 'simple_db.json');

router.post('/event', (req,res)=>{
  try{
    const { userId, event, props } = req.body || {};
    const raw = JSON.parse(fs.readFileSync(DB,'utf8'));
    raw.events[userId] = raw.events[userId] || [];
    raw.events[userId].push({ event, props: props||{}, ts: Date.now() });
    fs.writeFileSync(DB, JSON.stringify(raw,null,2));
    res.json({ ok:true });
  }catch(e){ console.error(e); res.status(500).json({ error:'failed' }) }
});

module.exports = router;
