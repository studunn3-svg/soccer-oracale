const express = require('express');
const router = express.Router();
const { getActiveEntitlement } = require('../../services/entitlements');

router.get('/prefs', async (req, res) => {
  // Demo stub - return a sample user
  res.json({ userId: 'user_123', favoriteTeam: null, favoriteLeague: 'Premier League', createdAt: new Date().toISOString() });
});

router.get('/subscription', async (req, res) => {
  const userId = (req.user && req.user.id) || 'user_123';
  const ent = await getActiveEntitlement({ userId });
  if (!ent) return res.json({ ok: true, autoRenewing: false, expiryTimeMs: 0, status: 'none' });
  res.json({ ok: true, autoRenewing: ent.autoRenewing, expiryTimeMs: Number(ent.expiryTimeMs), status: ent.status || 'active' });
});

module.exports = router;
