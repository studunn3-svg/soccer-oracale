const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const DB = path.join(__dirname, '..', 'lib', 'simple_db.json');

router.post('/favorite', (req,res)=>{
  try{
    const { userId, teamId } = req.body || {};
    if(!userId || !teamId) return res.status(400).json({ error: 'userId/teamId required' });
    const raw = JSON.parse(fs.readFileSync(DB,'utf8'));
    raw.favorites[userId] = { teamId, setAt: Date.now() };
    fs.writeFileSync(DB, JSON.stringify(raw,null,2));
    res.json({ ok:true, favoriteTeam: { id: teamId, name: teamId.replace('_',' ').toUpperCase(), primary:'#0055aa', secondary:'#00cc88' } });
  }catch(e){ console.error(e); res.status(500).json({ error:'failed' }) }
});

module.exports = router;
