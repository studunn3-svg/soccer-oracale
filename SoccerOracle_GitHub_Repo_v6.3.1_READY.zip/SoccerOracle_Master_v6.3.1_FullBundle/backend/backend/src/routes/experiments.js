const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const DB = path.join(__dirname, '..', 'lib', 'simple_db.json');

router.post('/assign', (req,res)=>{
  try{
    const { userId } = req.body || {};
    const raw = JSON.parse(fs.readFileSync(DB,'utf8'));
    if(!userId) return res.status(400).json({ error:'userId required' });
    if(raw.assignments[userId]) return res.json({ variant: raw.assignments[userId] });
    const variant = (Math.random() > 0.5) ? 'A' : 'B';
    raw.assignments[userId] = variant;
    fs.writeFileSync(DB, JSON.stringify(raw,null,2));
    res.json({ variant });
  }catch(e){ console.error(e); res.status(500).json({ error:'failed' }) }
});

module.exports = router;
