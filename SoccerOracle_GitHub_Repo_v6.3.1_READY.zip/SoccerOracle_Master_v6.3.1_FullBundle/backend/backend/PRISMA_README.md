# Entitlements DB (Prisma + SQLite)

## Setup
```bash
cd SoccerOracle_Master_v6.3.1_FullBundle/backend/backend
pnpm add -D prisma && pnpm add @prisma/client
npx prisma generate
npx prisma migrate dev --name init
```

This creates `prisma/dev.db` (SQLite).

## Usage in code
- `src/services/entitlements.js` provides `upsertEntitlement` and `getActiveEntitlement`.
- `/api/iap/google/verify` and `/api/iap/apple/verify` now upsert entitlements.
- `/api/me/subscription` reads the active entitlement for the current user (fallback demo user).

## Notes
- Replace demo `user_123` with your authenticated `req.user.id` once auth is wired.
- For production, switch `datasource db` in `prisma/schema.prisma` to Postgres/MySQL and run migrations.
