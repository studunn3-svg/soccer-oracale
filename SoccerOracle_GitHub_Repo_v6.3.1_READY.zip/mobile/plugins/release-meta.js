// Expo config plugin to stamp tag/version/commit into native builds
const { withInfoPlist, withAppBuildGradle, createRunOncePlugin } = require('@expo/config-plugins');
const pkg = { name: 'release-meta', version: '1.0.0' };
function withReleaseMeta(config) {
  const tag = process.env.RELEASE_TAG || '';
  const version = process.env.RELEASE_VERSION || (config?.expo?.version ?? '');
  const commit = process.env.EAS_BUILD_GIT_COMMIT_HASH || process.env.GITHUB_SHA || '';
  config = withInfoPlist(config, (c) => {
    c.modResults.ReleaseTag = tag;
    c.modResults.ReleaseVersion = version;
    c.modResults.ReleaseCommit = commit;
    return c;
  });
  config = withAppBuildGradle(config, (c) => {
    const contents = c.modResults.contents;
    const inject = `
  // >>> release meta (auto-injected)
  buildConfigField "String", "RELEASE_TAG", "\"${tag}\""
  buildConfigField "String", "RELEASE_VERSION", "\"${version}\""
  buildConfigField "String", "RELEASE_COMMIT", "\"${commit}\""
  // <<< release meta
`;
    if (!contents.includes('release meta (auto-injected)')) {
      c.modResults.contents = contents.replace(/defaultConfig\s*\{[\s\S]*?\n\s*\}/, (m) => m.replace(/\n\s*\}$/, inject + "\n}"));
    }
    return c;
  });
  return config;
}
module.exports = createRunOncePlugin(withReleaseMeta, pkg.name, pkg.version);
