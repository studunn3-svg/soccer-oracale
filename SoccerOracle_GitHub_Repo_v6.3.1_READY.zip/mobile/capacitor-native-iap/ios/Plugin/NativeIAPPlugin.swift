import Foundation
@objc public class NativeIAPPlugin: NSObject {}
