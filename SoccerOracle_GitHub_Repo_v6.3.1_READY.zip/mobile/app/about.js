import { View, Text, Button, Linking, Platform } from 'react-native';
import Constants from 'expo-constants';
import { useMemo } from 'react';

export default function About(){
  const extra = (Constants?.expoConfig?.extra) || {};
  const tag = extra.releaseTag || '—';
  const version = extra.releaseVersion || Constants?.expoConfig?.version || '—';
  const commit = extra.gitCommit || '—';
  const repo = extra.githubRepo || null;

  const commitUrl = useMemo(()=>{
    if (!repo || !commit || commit === '—') return null;
    if (repo.startsWith('http')) return `${repo.replace(/\.git$/, '')}/commit/${commit}`;
    return `https://github.com/${repo.replace(/\.git$/, '')}/commit/${commit}`;
  }, [repo, commit]);

  return (
    <View style={{ flex: 1, padding: 24, gap: 8, justifyContent: 'center' }}>
      <Text style={{ fontSize: 22, fontWeight: '600' }}>About</Text>
      <Text>Platform: {Platform.OS}</Text>
      <Text>Tag: {tag}</Text>
      <Text>Version: {version}</Text>
      <Text selectable={true} style={{ fontFamily: 'monospace' }}>Commit: {commit?.slice(0, 12) || '—'}</Text>
      {commitUrl ? <Button title="View Commit on GitHub" onPress={()=> Linking.openURL(commitUrl)} /> : null}
    </View>
  );
}
