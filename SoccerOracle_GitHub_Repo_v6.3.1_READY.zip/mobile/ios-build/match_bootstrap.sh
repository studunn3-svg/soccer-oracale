#!/usr/bin/env bash
set -euo pipefail
echo "== Fastlane Match Bootstrap =="
echo "This will initialize match for your team and create/app-store certificates in a private repo."
echo
if ! command -v fastlane >/dev/null 2>&1; then
  echo "Fastlane not installed. Install with: gem install fastlane"; exit 1; fi

read -p "Enter your Apple Developer Team ID: " TEAM_ID
read -p "Enter your App Identifier (e.g., com.yourcompany.Soccer Oracle): " APP_ID
read -p "Enter your private git repo for match (e.g., git@github.com:yourorg/certificates.git): " GIT_URL

export MATCH_PASSWORD=${MATCH_PASSWORD:-"set-a-strong-password"}

cat > Fastfile <<'EOF'
default_platform(:ios)

platform :ios do
  lane :setup_match do
    match(
      type: "appstore",
      readonly: false,
      git_branch: "main",
      git_url: ENV["MATCH_GIT_URL"],
      app_identifier: [ENV["APP_IDENTIFIER"]],
      username: ENV["APPLE_ID"],
      team_id: ENV["TEAM_ID"]
    )
  end
end
EOF

export MATCH_GIT_URL="$GIT_URL"
export APP_IDENTIFIER="$APP_ID"
export TEAM_ID="$TEAM_ID"
echo "Now run: APPLE_ID=<your-apple-id> bundle exec fastlane ios setup_match"
echo "When prompted, it will create/refresh certificates and profiles in your git repo."
