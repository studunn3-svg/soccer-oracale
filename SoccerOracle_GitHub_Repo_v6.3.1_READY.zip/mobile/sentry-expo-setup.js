import Constants from 'expo-constants';
import * as Sentry from 'sentry-expo';
const extra = (Constants?.expoConfig?.extra)||{};
const dsn = extra.sentryDsn;
const tracesSampleRate = Number(extra.sentryTracesSampleRate ?? 0.2);
const profilesSampleRate = Number(extra.sentryProfilesSampleRate ?? 0);
if (dsn) {
  Sentry.init({
    dsn,
    enableInExpoDevelopment: true,
    debug: false,
    tracesSampleRate,
    profilesSampleRate,
    enableAutoPerformanceTracing: true,
  });
}

// Injected: read sampling rates from env (with sane defaults)
const tracesRate = Number(process.env.EXPO_PUBLIC_SENTRY_TRACES_SAMPLE_RATE || 0.1);
const profilesRate = Number(process.env.EXPO_PUBLIC_SENTRY_PROFILES_SAMPLE_RATE || 0.05);
Sentry.init({
  dsn: process.env.EXPO_PUBLIC_SENTRY_DSN || Sentry.Native?.dsn,
  enableInExpoDevelopment: true,
  tracesSampleRate: tracesRate,
  profilesSampleRate: profilesRate,
});
