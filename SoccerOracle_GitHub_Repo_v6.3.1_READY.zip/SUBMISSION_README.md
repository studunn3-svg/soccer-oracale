# Soccer Oracle v6.3.1 — Store Submission Guide

Use Validate workflow first (no secrets). Then add signing secrets to build uploadable AAB / IPA.
Run `tools/preflight.sh` to verify structure before building.
