
# SoccerOracle – One-Time Setup Checklist

This guide gets your repo ready to cut releases with strict provenance, Sentry, and store submissions.

---

## 1) GitHub → Settings

### a) **Secrets and variables → Actions → Secrets**
Add these **Secrets**:

**Expo/EAS**
- `EXPO_TOKEN` — Personal access token from Expo (EAS).
- `EXPO_PUBLIC_API_BASE` — Production API base (e.g. `https://api.yourdomain.com`).
- `WEB_STAGING_API_BASE` — Staging API base (e.g. `https://staging.api.yourdomain.com`).

**Sentry**
- `SENTRY_AUTH_TOKEN`
- `SENTRY_ORG`
- `SENTRY_PROJECT`
- `NEXT_PUBLIC_SENTRY_DSN`

**GitHub links**
- `NEXT_PUBLIC_GITHUB_REPO` — e.g. `org/repo` (used by web UI commit links and mobile About).

**Expo links (optional but recommended for Release notes deep-links)**
- `EAS_ACCOUNT` — Expo account/owner (e.g. `your-expo-account`)
- `EAS_PROJECT` — Expo project slug (e.g. `socceroracle`)

**Google Play submit**
- `GOOGLE_PLAY_JSON` — Entire JSON from the Play Console service account (used by `eas submit`).

**Notifications (optional)**
- `SLACK_WEBHOOK_URL`
- `DISCORD_WEBHOOK_URL`

---

### b) **Secrets and variables → Actions → Variables**
Add these **Variables** (repository variables, not secrets):

**Release body summary controls (defaults okay):**
- `EAS_SUMMARY_ONLY_FINISHED` = `true` — show only Finished builds/submissions in notes.
- `EAS_SUMMARY_ROWS` = `5` — rows per table/list.
- `EAS_SUMMARY_ENABLE_TABLES` = `true` — `false` renders bullet lists instead.

**Strict gates (optional, enable to enforce):**
- `EAS_REQUIRE_BUILDS_FINISHED` = `any` | `both`/`all` | `true` (alias `any`)
- `EAS_FAIL_ON_BUILD_FAILURES` = `true` (fail if any build Failed/Errored/Canceled)
- `EAS_REQUIRE_SUBMISSIONS_FINISHED` = `any` | `both`/`all` | `true`
- `EAS_FAIL_ON_SUBMISSION_ERRORS` = `true`

---

## 2) Project configuration

### a) `mobile/app.json`
Make sure these exist (the bundle already includes them):
```json
{
  "expo": {
    "owner": "YOUR_EXPO_ACCOUNT",
    "slug": "socceroracle",
    "plugins": ["sentry-expo", "./plugins/release-meta"],
    "extra": {
      "apiBase": {"$env":"EXPO_PUBLIC_API_BASE"},
      "githubRepo": {"$env":"EXPO_PUBLIC_GITHUB_REPO"},
      "sentryDsn": {"$env": "EXPO_PUBLIC_SENTRY_DSN"}
    }
  }
}
```

### b) `apps/web/.env.staging` and `.env.production`
Set:
```
NEXT_PUBLIC_API_BASE=https://staging.api.yourdomain.com  # staging
NEXT_PUBLIC_API_BASE=https://api.yourdomain.com          # production
NEXT_PUBLIC_SENTRY_DSN=
NEXT_PUBLIC_GITHUB_REPO=org/repo
```

> Tip: You can also rely on GitHub Actions to pass these via env during the web build; keeping files helps local dev.

---

## 3) First-time dry run (local)

- Backend: `cd SoccerOracle_Master_v6.3.1_FullBundle/backend/backend && npm i && npm start`
- Web: `cd apps/web && pnpm i && pnpm dev` → open `/admin/deployments`
- Mobile: `cd mobile && npm i` then `npx expo start` (About screen at `/about`).

---

## 4) Cutting a release

1. **Prepare**: In GitHub → Actions → **Prepare Release**, pick `patch|minor|major`.  
   This bumps versions/build numbers, updates CHANGELOG, commits, **tags** (`vX.Y.Z`) and **pushes**.
2. **Release**: The new tag triggers **Release (Matrix: staging & production)**:
   - EAS builds (iOS/Android) + submit (internal/production).
   - Sentry release create/finalize.
   - Strict checks:
     - Tag ↔ `mobile/app.json` **version** must match.
     - `mobile/build-meta.json` **commit** must equal tag commit.
     - **EAS build** commit must match tag commit.
   - GitHub Release:
     - Attaches AAB/IPA, screenshots/PDFs, **build/submission JSON logs**.
     - Release body includes **Build Summary** + **Submissions** tables with **deep links**.

---

## 5) Troubleshooting

- **Version mismatch**: Update `mobile/app.json` version to match tag or re-run Prepare Release.
- **Commit mismatch**: Ensure the EAS build picked up the tag’s commit (the hook writes `mobile/build-meta.json`). Rebuild if needed.
- **Missing artifacts**: Confirm `EXPO_TOKEN` is set; `eas build:download` requires it.
- **No deep links**: Set `expo.owner` and `expo.slug` in `mobile/app.json` or Secrets `EAS_ACCOUNT` / `EAS_PROJECT`.
- **Play submit fails**: Verify `GOOGLE_PLAY_JSON` is the full JSON; confirm Play tracks/permissions.
- **Sentry not receiving**: Check DSN values on web/mobile; verify `SENTRY_AUTH_TOKEN`, `SENTRY_ORG`, `SENTRY_PROJECT`.

---

## 6) Security notes
- Store tokens as **Secrets**. Use **Variables** for non-sensitive gates/toggles.
- The workflow uses **strict provenance**. Any mismatch will **fail** the release to prevent untraceable binaries.

---

## 7) Done? Ship it!
- Run **Prepare Release** → tag pushed.  
- Watch **Release** workflow; on success, GitHub Release will have artifacts, links, and summary tables.  
- Slack/Discord webhooks (if set) will post status + links automatically.


---

## 8) (Optional) API health checks in CI

Set repository variables if you want the Release workflow to verify API reachability before creating the release:

- `API_HEALTH_URL_STAGING` = `https://staging.api.yourdomain.com/health`
- `API_HEALTH_URL_PRODUCTION` = `https://api.yourdomain.com/health`
- `REQUIRE_HEALTH_OK` = `true` to enforce checks (fail release if health returns `{ ok: false }`)

The backend now serves `GET /health` returning `{ ok, version, commit, uptime, ts }`.


---

## 9) (Optional) Guardrails for Sentry sampling in CI

You can enforce upper limits on sampling rates before a release is created. Set repository variables (defaults in parentheses):

- `SENTRY_MAX_TRACES_RATE_PROD` (0.1)
- `SENTRY_MAX_PROFILES_RATE_PROD` (0.05)
- `SENTRY_MAX_TRACES_RATE_STAGING` (0.5)
- `SENTRY_MAX_PROFILES_RATE_STAGING` (0.2)

The workflow validates:
- Web: reads `apps/web/.env.<env>`
- Mobile: reads `mobile/eas.json` per build profile


- `SENTRY_REQUIRE_DSN_PROD` (default `true`) — require DSN for production (web `.env.production`, mobile `eas.json`).
- `SENTRY_REQUIRE_DSN_STAGING` (default `false`) — optionally require DSN for staging builds.


---

## 10) (Optional) Sentry error budget gate

Before publishing a release, CI can query Sentry to ensure reliability is within budget.

**Modes:**
- `SENTRY_GUARD_MODE=events` (default) — checks `event.type:error` vs `event.type:transaction` in the last `SENTRY_ERROR_RATE_WINDOW_MIN` minutes (default 30). Fails when `errors/transactions > SENTRY_ERROR_RATE_MAX` (default `0.05`). If no transactions, falls back to `SENTRY_ERRORS_MAX` (default `50`).
- `SENTRY_GUARD_MODE=sessions` — checks crash-free sessions in the last window; fails when `< SENTRY_MIN_CRASH_FREE_SESSIONS` (default `0.98`).

**Required secrets:** `SENTRY_AUTH_TOKEN`, `SENTRY_ORG`, `SENTRY_PROJECT` (already used by the pipeline).

> Tune: `SENTRY_ERROR_RATE_WINDOW_MIN`, `SENTRY_ERROR_RATE_MAX`, `SENTRY_ERRORS_MAX`, `SENTRY_MIN_CRASH_FREE_SESSIONS` as needed.

- If the Sentry error budget gate fails, the workflow creates/updates a **draft** Release for the tag with a failure note and links to Sentry.

**Override once?**  
- Set repository variable `SENTRY_GUARD_OVERRIDE=true` and re-run the failed job, **or**  
- Go to **Actions → Release → Run workflow**, toggle **override_guard=true**, and select the release tag.  
In both cases, CI will append an **OVERRIDDEN** audit note to the tag’s Release.


---

## 11) Entitlements storage

By default, webhook events persist to a **file-backed** store (`tmp_entitlements.json`). To switch to SQLite, set:

- `ENTITLEMENTS_BACKEND=sqlite`
- `ENTITLEMENTS_SQLITE_PATH=./tmp_entitlements.sqlite` (optional)

Endpoints added:
- `POST /iap/google/rtdn` — persists Android notifications (token/productId/status).
- `POST /iap/apple/assn` — persists Apple notifications (transactionId/productId/status/expiry when available).
- `GET /admin/entitlements` — list recent stored rows (for internal admin use only).

> Map notifications to users: include a `userId` in your client validation calls and persist it alongside token/transaction IDs, or resolve userId lazily when validating receipts.


---

## 12) Store metadata via Fastlane (optional)

You can publish **listing metadata only** (no binaries) during the Release workflow.

Set repository **Variables**:
- `RUN_FASTLANE_DELIVER=true` to enable iOS metadata upload
- `RUN_FASTLANE_SUPPLY=true` to enable Android metadata upload
- `IOS_APP_IDENTIFIER`, `APP_STORE_APPLE_ID` (iOS)
- `ANDROID_PACKAGE_NAME`, `PLAY_TRACK` (Android; default `alpha`)

Set **Secrets**:
- `APP_STORE_CONNECT_API_KEY_JSON` (App Store Connect API key JSON)
- `GOOGLE_PLAY_JSON` (already used by EAS submit; also works for `supply`)

The workflow job **Store Metadata (Fastlane deliver/supply)** runs after build gates. It uploads text metadata from:
- `fastlane/metadata/en-US`, `fastlane/metadata/en-GB` (iOS)
- `fastlane/metadata/android/en-US`, `en-GB` (Android)


---

## 13) Optional screenshot uploads

Enable uploads by setting repository variables:

- `RUN_FASTLANE_DELIVER_SCREENSHOTS=true` (iOS) and/or
- `RUN_FASTLANE_SUPPLY_SCREENSHOTS=true` (Android)

Paths:
- `IOS_SCREENSHOTS_PATH` → defaults to `fastlane/screenshots`
  - Place images under `fastlane/screenshots/<locale>/` (e.g., `en-US/`) as per fastlane conventions.
- `ANDROID_SCREENSHOTS_PATH` → defaults to `fastlane/metadata/android`
  - Place images under `fastlane/metadata/android/<locale>/*Screenshots/` (e.g., `phoneScreenshots/`).

Using generated sets:
- Set `DOWNLOAD_SCREENSHOTS_ARTIFACT=true` and `STORE_SCREENSHOTS_ARTIFACT_NAME=store-screenshots` (or your artifact name).
- CI will download and unpack into `fastlane/` automatically before upload.


---

## 14) Screenshot linter (counts, filenames, dimensions)

Before uploading screenshots (when enabled), CI runs a linter that checks:
- **Counts** per locale (defaults: iOS ≥ 5, Android phone ≥ 5).
- **Filenames**: must start with `01_`…`10_` (e.g., `01_home.png`).
- **Dimensions** (optional): iOS allows common Apple sizes or portrait ratios; Android enforces Play bounds and aspect rule.

Customize via Variables:
- `LOCALES` (default `en-US,en-GB`)
- `IOS_SCREENSHOTS_MIN_COUNT` (default `5`)
- `ANDROID_PHONE_MIN_COUNT` (default `5`)
- `CHECK_DIMS` (default `true`)

See `docs/screenshot_device_matrix.md` for recommended sizes and folders.


---

## 15) Auto-name screenshots from overlays

Turn on `RUN_SCREENSHOT_AUTONAME=true` to automatically map raw images to `01_…` filenames/order per locale using your overlays CSV (`screenshots/overlays_<locale>.csv`).

**How it works**
- Looks for raw images in `fastlane/_raw/ios/<locale>/` and `fastlane/_raw/android/<locale>/phone/`. If none, it renames in the final folders instead.
- Reads `headline` from the overlays CSV to build a short slug (e.g., `01_smart-match-insights.png`).
- Copies (or renames in place) into:
  - iOS → `fastlane/screenshots/<locale>/`
  - Android → `fastlane/metadata/android/<locale>/phoneScreenshots/`
- Writes `tools/screenshot_rename_report.json` with a mapping summary.

Tip: Combine with the **artifact download** step to pull generated screenshots, then auto-name, lint, and upload in one run.


---

## 16) Optional overlay rendering (ImageMagick)

Set `RUN_RENDER_OVERLAYS=true` to burn overlay headlines/subheads from your `screenshots/overlays_<locale>.csv` onto the images automatically.

- Uses **ImageMagick** on GitHub runners (we install it in CI).
- Outputs to `fastlane/_rendered/...`, which the auto-namer prefers.
- Tuning knobs via Variables: `PANEL_HEIGHT_PCT`, `OVERLAY_PADDING`, `HEADLINE_SIZE_PCT`, `SUBHEAD_SIZE_PCT`, `OVERLAY_FONT`, `OVERLAY_COLOR_HEAD`, `OVERLAY_COLOR_SUB`, `OVERLAY_PANEL_COLOR`.
