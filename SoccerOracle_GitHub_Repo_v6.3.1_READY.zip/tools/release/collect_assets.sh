#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.."; pwd)"
ART="$ROOT/artifacts"
rm -rf "$ART" && mkdir -p "$ART"
cd "$ROOT"
if compgen -G "store/**/*.png" > /dev/null; then zip -r "$ART/Store_Screenshots.zip" store -i "*.png" >/dev/null; fi
if [ -d "policies" ]; then zip -r "$ART/Policies.zip" policies >/dev/null; fi
if compgen -G "docs/*.pdf" > /dev/null; then zip -r "$ART/Docs_PDFs.zip" docs -i "*.pdf" >/dev/null; fi
zip -j "$ART/Docs_Core.zip" CHANGELOG.md BUILDING.md SUBMISSION_README.md 2>/dev/null || true
echo "Collected assets in $ART:"; ls -la "$ART" || true
