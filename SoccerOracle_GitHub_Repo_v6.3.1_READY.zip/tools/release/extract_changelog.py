import re, sys
from pathlib import Path
root = Path(__file__).resolve().parents[2]
changelog = root/"CHANGELOG.md"
if not changelog.exists():
  print("# Release Notes\n\nNo CHANGELOG.md found."); sys.exit(0)
if len(sys.argv)<2:
  print("Usage: extract_changelog.py vX.Y.Z", file=sys.stderr); sys.exit(1)
tag = sys.argv[1].lstrip('v')
text = changelog.read_text()
pattern = re.compile(rf"^##\s+{re.escape(tag)}\b.*$", re.M)
m = pattern.search(text)
if not m:
  print(f"# Release {tag}\n\nNo matching section found in CHANGELOG.md."); sys.exit(0)
start = m.start()
m2 = re.search(r"^##\s+\d+\.\d+\.\d+\b.*$", text[m.end():], re.M)
section = text[start:] if not m2 else text[start:m.end()+m2.start()]
print(section.strip())
