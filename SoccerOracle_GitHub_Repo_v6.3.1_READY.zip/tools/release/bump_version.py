#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
from datetime import date
root = Path(__file__).resolve().parents[2]
version_file = root/"VERSION"
def read_version(): return version_file.read_text().strip() if version_file.exists() else "6.3.1"
def write_version(v): version_file.write_text(v+"\n")
def inc(v, kind):
  major, minor, patch = map(int, v.split("."))
  if kind=="major": return f"{major+1}.0.0"
  if kind=="minor": return f"{major}.{minor+1}.0"
  return f"{major}.{minor}.{patch+1}"
def update_json(p, key="version", value=None):
  d = json.loads(Path(p).read_text()); d[key] = value; Path(p).write_text(json.dumps(d, indent=2))
def update_appjson_version(p, value):
  d = json.loads(Path(p).read_text()); d["expo"]["version"] = value; Path(p).write_text(json.dumps(d, indent=2))
def androidVersionCodeFrom(v):
  major, minor, patch = map(int, v.split(".")); return major*10000 + minor*100 + patch
def update_appjson_extra(p, value):
  d = json.loads(Path(p).read_text())
  d["expo"].setdefault("ios", {}); d["expo"]["ios"]["buildNumber"] = value
  d["expo"].setdefault("android", {}); d["expo"]["android"]["versionCode"] = androidVersionCodeFrom(value)
  Path(p).write_text(json.dumps(d, indent=2))
def replace_in_file(p, pattern, repl):
  t = Path(p).read_text(); Path(p).write_text(re.sub(pattern, repl, t))
def collect_commits():
  import subprocess
  try: out = subprocess.check_output(["git","log","--pretty=format:%s","-n","200"], text=True); return out.splitlines()
  except Exception: return []
def categorize(commits):
  cats = {"feat":[],"fix":[],"perf":[],"docs":[],"chore":[],"other":[]}
  for c in commits:
    lc = c.lower()
    if lc.startswith("feat"): cats["feat"].append(c)
    elif lc.startswith("fix"): cats["fix"].append(c)
    elif lc.startswith("perf"): cats["perf"].append(c)
    elif lc.startswith("docs"): cats["docs"].append(c)
    elif lc.startswith("chore"): cats["chore"].append(c)
    else: cats["other"].append(c)
  return cats
def write_changelog(version, cats):
  chlog = root/"CHANGELOG.md"; today = date.today().isoformat()
  lines = [f"## {version} - {today}"]
  for k in ["feat","fix","perf","docs","chore","other"]:
    if cats[k]:
      title = {"feat":"Features","fix":"Fixes","perf":"Performance","docs":"Docs","chore":"Chores","other":"Other"}[k]
      lines.append(f"### {title}"); [lines.append(f"- {c}") for c in cats[k]]
  lines.append(""); new = "\n".join(lines)
  chlog.write_text(new + chlog.read_text()) if chlog.exists() else chlog.write_text("# Changelog\n\n"+new)
def main():
  bump = (sys.argv[1] if len(sys.argv)>1 else "patch").lower()
  if bump not in ("major","minor","patch"): print("Usage: bump_version.py [major|minor|patch]"); sys.exit(1)
  cur = read_version(); new = inc(cur, bump); write_version(new)
  update_json(root/"apps/web/package.json", value=new)
  # backend package.json path (best-effort if exists)
  bp = root/"SoccerOracle_Master_v6.3.1_FullBundle/backend/backend/package.json"
  if bp.exists(): update_json(bp, value=new)
  update_json(root/"mobile/package.json", value=new)
  update_appjson_version(root/"mobile/app.json", value=new); update_appjson_extra(root/"mobile/app.json", value=new)
  try: replace_in_file(root/"SUBMISSION_README.md", r"v\d+\.\d+\.\d+", "v"+new)
  except Exception: pass
  commits = collect_commits(); cats = categorize(commits); write_changelog(new, cats); print(new)
if __name__=="__main__": main()
