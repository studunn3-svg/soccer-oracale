
/**
 * Auto-names & copies raw screenshots into Fastlane folders based on overlays CSV.
 *
 * Inputs via env (repo Variables are fine):
 *   PLATFORM: "ios" | "android" | "both" (default "both")
 *   LOCALES: "en-US,en-GB" (default)
 *   OVERLAYS_DIR: path to overlays CSVs (default "screenshots")
 *   IOS_INPUT_DIR: default "fastlane/_raw/ios/<locale>" (fallback to "fastlane/screenshots/<locale>")
 *   ANDROID_INPUT_DIR: default "fastlane/_raw/android/<locale>/phone" (fallback to "fastlane/metadata/android/<locale>/phoneScreenshots")
 *   IOS_OUTPUT_DIR: default "fastlane/screenshots/<locale>"
 *   ANDROID_OUTPUT_DIR: default "fastlane/metadata/android/<locale>/phoneScreenshots"
 *   MAX_FRAMES: optional cap (e.g., "5")
 *   DRY_RUN: "true" to only print actions
 *
 * Behavior:
 *   - Reads overlays CSV per locale: overlays_<locale>.csv with columns: frame, headline, subhead
 *   - Sorts input images by filename then mtime, maps first N to overlay rows
 *   - Slug = sanitized headline (lowercase, a–z0–9, dashes), trimmed to 30 chars
 *   - Output filenames: 01_<slug>.png ... 10_<slug>.png (keeps PNG/JPG ext)
 *   - Writes tools/screenshot_rename_report.json with mappings
 */
const fs = require('fs');
const path = require('path');

function listImages(dir){
  try{
    const files = fs.readdirSync(dir).map(f=>path.join(dir,f));
    return files.filter(f=>/\.(png|jpg|jpeg)$/i.test(f));
  }catch(_){ return []; }
}
function mtime(p){ try{ return fs.statSync(p).mtimeMs || 0; }catch(_){ return 0; } }
function ensureDir(d){ fs.mkdirSync(d, { recursive: true }); }
function slugify(s){
  return String(s||'frame').toLowerCase()
    .replace(/&/g,' and ')
    .replace(/[^a-z0-9]+/g,'-')
    .replace(/^-+|-+$/g,'')
    .slice(0,30) || 'frame';
}
function readCSV(p){
  try{
    const t = fs.readFileSync(p,'utf8').trim();
    const lines = t.split(/\r?\n/).filter(Boolean);
    const header = lines.shift().split(',').map(s=>s.trim());
    const idx = Object.fromEntries(header.map((h,i)=>[h.toLowerCase(), i]));
    return lines.map(line=>{
      const cells = line.split(',').map(s=>s.trim());
      return {
        frame: Number(cells[idx['frame']]||cells[0]||0),
        headline: cells[idx['headline']] || '',
        subhead: cells[idx['subhead']] || ''
      };
    }).sort((a,b)=>a.frame-b.frame);
  }catch(_){ return []; }
}

const PLATFORM = (process.env.PLATFORM || 'both').toLowerCase();
const LOCALES = (process.env.LOCALES || 'en-US,en-GB').split(',').map(s=>s.trim()).filter(Boolean);
const OVERLAYS_DIR = process.env.OVERLAYS_DIR || 'screenshots';
const MAX_FRAMES = process.env.MAX_FRAMES ? parseInt(process.env.MAX_FRAMES,10) : null;
const DRY = String(process.env.DRY_RUN||'false').toLowerCase()==='true';

let report = { when: new Date().toISOString(), locales: {}, dryRun: DRY };

function mapSet({platform, locale, inputDir, outputDir, overlaysCsv}){
  const imgs = listImages(inputDir).sort((a,b)=>{
    const na = path.basename(a).toLowerCase();
    const nb = path.basename(b).toLowerCase();
    if(na<nb) return -1; if(na>nb) return 1;
    return mtime(a)-mtime(b);
  });
  let overlays = readCSV(overlaysCsv);
  if (MAX_FRAMES) overlays = overlays.slice(0, MAX_FRAMES);
  const n = Math.min(imgs.length, overlays.length || imgs.length);
  const actions = [];
  if(n===0){
    return { ok:false, reason:`No images found in ${inputDir}` };
  }
  ensureDir(outputDir);
  for(let i=0;i<n;i++){
    const src = imgs[i];
    const ov = overlays[i] || { frame: i+1, headline: path.basename(src) };
    const num = (i+1).toString().padStart(2,'0');
    const slug = slugify(ov.headline || ov.subhead || `frame-${i+1}`);
    const ext = path.extname(src).toLowerCase();
    const dst = path.join(outputDir, `${num}_${slug}${ext}`);
    actions.push({ i, src, dst, headline: ov.headline, subhead: ov.subhead });
    if(!DRY){
      fs.copyFileSync(src, dst);
    }
  }
  return { ok:true, inputDir, outputDir, count:n, actions };
}

for(const loc of LOCALES){
  const overlaysCsv = path.join(OVERLAYS_DIR, `overlays_${loc}.csv`);
  const localeRep = report.locales[loc] = { ios:null, android:null };

  if(PLATFORM==='ios' || PLATFORM==='both'){
    // determine input dir
    let inCandidates = [
      path.join('fastlane','_rendered','ios',loc),
      path.join('fastlane','_raw','ios',loc),
      path.join('fastlane','screenshots',loc) // fallback
    ];
    let inputDir = inCandidates.find(d=>listImages(d).length>0) || inCandidates[0];
    let outputDir = path.join('fastlane','screenshots',loc);
    const r = mapSet({ platform:'ios', locale:loc, inputDir, outputDir, overlaysCsv });
    localeRep.ios = r;
    console.log('iOS', loc, r.ok?`→ ${r.count} files`:`skip (${r.reason||'no files'})`, '@', inputDir, '->', outputDir);
  }

  if(PLATFORM==='android' || PLATFORM==='both'){
    let inCandidates = [
      path.join('fastlane','_rendered','android',loc,'phone'),
      path.join('fastlane','_raw','android',loc,'phone'),
      path.join('fastlane','metadata','android',loc,'phoneScreenshots')
    ];
    let inputDir = inCandidates.find(d=>listImages(d).length>0) || inCandidates[0];
    let outputDir = path.join('fastlane','metadata','android',loc,'phoneScreenshots');
    const r = mapSet({ platform:'android', locale:loc, inputDir, outputDir, overlaysCsv });
    localeRep.android = r;
    console.log('Android', loc, r.ok?`→ ${r.count} files`:`skip (${r.reason||'no files'})`, '@', inputDir, '->', outputDir);
  }
}

try{
  require('fs').writeFileSync('tools/screenshot_rename_report.json', JSON.stringify(report, null, 2));
}catch(_){}

console.log('\nDone.');
process.exit(0);
