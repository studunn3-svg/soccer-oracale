
/**
 * Lints store screenshots for counts, filenames, and optional dimensions.
 * Env (repo variables are fine):
 *   LOCALES = "en-US,en-GB"
 *   IOS_SCREENSHOTS_PATH = "fastlane/screenshots"
 *   ANDROID_SCREENSHOTS_PATH = "fastlane/metadata/android"
 *   IOS_SCREENSHOTS_MIN_COUNT = "5"
 *   ANDROID_PHONE_MIN_COUNT = "5"
 *   CHECK_DIMS = "true" | "false"
 */
const fs = require('fs');
const path = require('path');
const sizeOf = require('image-size');

const LOCALES = (process.env.LOCALES || 'en-US,en-GB').split(',').map(s=>s.trim()).filter(Boolean);
const IOS_DIR = process.env.IOS_SCREENSHOTS_PATH || 'fastlane/screenshots';
const ANDROID_DIR = process.env.ANDROID_SCREENSHOTS_PATH || 'fastlane/metadata/android';
const IOS_MIN = parseInt(process.env.IOS_SCREENSHOTS_MIN_COUNT || '5', 10);
const AND_MIN = parseInt(process.env.ANDROID_PHONE_MIN_COUNT || '5', 10);
const CHECK_DIMS = String(process.env.CHECK_DIMS || 'true').toLowerCase() === 'true';

const allowedExt = new Set(['.png', '.jpg', '.jpeg']);
const prefixRE = /^(0[1-9]|10)[-_]/i;

const iosRecommendedDims = new Set(['1290x2796','1284x2778','1242x2688','2048x2732','1242x2208']);
function dimKey(w,h){return `${w}x${h}`;}

function listFiles(dir){
  try { return fs.readdirSync(dir).map(f=>path.join(dir,f)); } catch(_){ return []; }
}
function isImage(p){
  const ext = path.extname(p).toLowerCase();
  return allowedExt.has(ext);
}
function dimInfo(p){
  try { const d=sizeOf(p); return {w:d.width,h:d.height}; } catch(_){ return null; }
}

let failures = 0;
function fail(msg){ console.error("✖", msg); failures++; }
function ok(msg){ console.log("✔", msg); }

console.log("Locales:", LOCALES.join(', '));

// iOS checks
for(const loc of LOCALES){
  const d = path.join(IOS_DIR, loc);
  const files = listFiles(d).filter(isImage);
  if(files.length < IOS_MIN){
    fail(`iOS ${loc}: found ${files.length} images < minimum ${IOS_MIN} in ${d}`);
  } else {
    ok(`iOS ${loc}: ${files.length} images`);
  }
  for(const f of files){
    const base = path.basename(f);
    if(!prefixRE.test(base)){
      fail(`iOS ${loc}: file lacks numeric prefix 01..10: ${base}`);
    }
    if(CHECK_DIMS){
      const dim = dimInfo(f);
      if(!dim){ fail(`iOS ${loc}: cannot read dimensions for ${base}`); continue; }
      const key = dimKey(dim.w, dim.h);
      if(!iosRecommendedDims.has(key)){
        // Allow portrait with aspect ~9:19.5 (tolerance), otherwise warn/fail
        const ratio = dim.h / dim.w;
        const okRatio = ratio > 1.9 && ratio < 2.3; // loose tolerance
        if(!okRatio){
          fail(`iOS ${loc}: unexpected dimensions ${key} for ${base}`);
        } else {
          console.log(`ℹ iOS ${loc}: non-standard size ${key} (ratio ${ratio.toFixed(2)}) for ${base}`);
        }
      }
    }
  }
}

// Android phone checks
for(const loc of LOCALES){
  const d = path.join(ANDROID_DIR, loc, 'phoneScreenshots');
  const files = listFiles(d).filter(isImage);
  if(files.length < AND_MIN){
    fail(`Android phone ${loc}: found ${files.length} images < minimum ${AND_MIN} in ${d}`);
  } else {
    ok(`Android phone ${loc}: ${files.length} images`);
  }
  for(const f of files){
    const base = path.basename(f);
    if(!prefixRE.test(base)){
      fail(`Android ${loc}: file lacks numeric prefix 01..10: ${base}`);
    }
    if(CHECK_DIMS){
      const dim = dimInfo(f);
      if(!dim){ fail(`Android ${loc}: cannot read dimensions for ${base}`); continue; }
      const w=dim.w,h=dim.h;
      const min=320,max=3840;
      const within = (v)=> v>=min && v<=max;
      if(!(within(w)&&within(h))){
        fail(`Android ${loc}: dimensions out of Play bounds ${w}x${h} for ${base}`);
      }
      const ratioOK = Math.max(w,h) <= 2*Math.min(w,h);
      if(!ratioOK){
        fail(`Android ${loc}: longest side > 2x shortest for ${base}`);
      }
    }
  }
}

if(failures>0){
  console.error(`\n✖ Screenshot lint failed with ${failures} error(s).`);
  process.exit(2);
} else {
  console.log("\n✔ Screenshot lint passed.");
}
