#!/usr/bin/env bash
set -euo pipefail
echo "== Soccer Oracle v6.3.1 Preflight =="
ROOT="$(cd "$(dirname "$0")/.."; pwd)"
ok=1
check() { [ -e "$1" ] && echo "[OK] $1" || { echo "[MISS] $1"; ok=0; }; }

check "$ROOT/SoccerOracle_Master_v6.3.1_FullBundle/backend/backend/src/server.js"
check "$ROOT/SoccerOracle_Master_v6.3.1_FullBundle/backend/backend/src/routes/iap/apple.js"
check "$ROOT/SoccerOracle_Master_v6.3.1_FullBundle/backend/backend/src/routes/iap/google.js"
check "$ROOT/SoccerOracle_Master_v6.3.1_FullBundle/backend/backend/src/services/iap/apple.js"
check "$ROOT/SoccerOracle_Master_v6.3.1_FullBundle/backend/backend/src/services/iap/google.js"
check "$ROOT/apps/web/components/Paywall.tsx"
check "$ROOT/apps/web/components/PersonalizedPaywall.tsx"
check "$ROOT/apps/web/components/SubscriptionStatus.tsx"
check "$ROOT/apps/web/app/api/subscription/status/route.ts"
check "$ROOT/apps/web/app/admin/dashboard/page.tsx"
check "$ROOT/mobile/capacitor-native-iap/android/src/main/java/com/yourcompany/nativeiap/NativeIAPPlugin.kt"
check "$ROOT/mobile/capacitor-native-iap/ios/Plugin/NativeIAPPlugin.swift"
check "$ROOT/.github/workflows/build_mobile.yml"
check "$ROOT/.github/workflows/validate.yml"
check "$ROOT/BUILDING.md"

if [ "$ok" == "1" ]; then echo "Preflight checks passed (structure)."; else echo "Some files are missing."; exit 1; fi
