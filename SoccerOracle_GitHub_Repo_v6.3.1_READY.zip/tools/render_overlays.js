
/**
 * Render overlay text (headline + subhead) onto screenshots using ImageMagick.
 * For each locale, reads overlays CSV (screenshots/overlays_<locale>.csv)
 * and applies a lower-third panel to images found in *_raw/* (or final folders).
 *
 * Env:
 *   PLATFORM: ios|android|both (default both)
 *   LOCALES: "en-US,en-GB" (default)
 *   OVERLAYS_DIR: path to CSVs (default "screenshots")
 *   IOS_INPUT_DIR: default fastlane/_raw/ios/<locale>/ (fallback fastlane/screenshots/<locale>/)
 *   ANDROID_INPUT_DIR: default fastlane/_raw/android/<locale>/phone/ (fallback fastlane/metadata/android/<locale>/phoneScreenshots/)
 *   RENDERED_DIR: base dir for outputs (default fastlane/_rendered)
 *   PANEL_HEIGHT_PCT: bottom panel height percent (default 22)
 *   PADDING: px left/right padding (default 48)
 *   HEADLINE_SIZE_PCT: % of image height for headline font (default 4.2)
 *   SUBHEAD_SIZE_PCT: % of image height for subhead font (default 2.6)
 *   FONT: font name installed on runner (default "Arial")
 *   COLOR_HEAD: text color (default "white")
 *   COLOR_SUB: text color (default "#f0f0f0")
 *   PANEL_COLOR: like "#000000AA" (default "#000000AA")
 *   DRY_RUN: "true" to only print actions
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

function listImages(dir){
  try { return fs.readdirSync(dir).filter(f=>/\.(png|jpg|jpeg)$/i.test(f)).map(f=>path.join(dir,f)); } catch(_){ return []; }
}
function ensureDir(d){ fs.mkdirSync(d,{recursive:true}); }
function sh(cmd){
  try { return execSync(cmd, { stdio: 'pipe' }).toString(); } catch(e){ throw new Error(`Command failed: ${cmd}\n${e.stderr?e.stderr.toString():e.message}`); }
}

const PLATFORM = (process.env.PLATFORM || 'both').toLowerCase();
const LOCALES = (process.env.LOCALES || 'en-US,en-GB').split(',').map(s=>s.trim()).filter(Boolean);
const OVERLAYS_DIR = process.env.OVERLAYS_DIR || 'screenshots';
const RENDERED_DIR = process.env.RENDERED_DIR || 'fastlane/_rendered';
const PANEL = parseFloat(process.env.PANEL_HEIGHT_PCT || '22');
const PAD = parseInt(process.env.PADDING || '48',10);
const HEAD_PCT = parseFloat(process.env.HEADLINE_SIZE_PCT || '4.2');
const SUB_PCT = parseFloat(process.env.SUBHEAD_SIZE_PCT || '2.6');
const FONT = process.env.FONT || 'Arial';
const COLOR_H = process.env.COLOR_HEAD || 'white';
const COLOR_S = process.env.COLOR_SUB || '#f0f0f0';
const PANEL_COLOR = process.env.PANEL_COLOR || '#000000AA';
const DRY = String(process.env.DRY_RUN || 'false').toLowerCase()==='true';

function readCSV(p){
  try{
    const t = fs.readFileSync(p,'utf8').trim();
    const lines = t.split(/\r?\n/).filter(Boolean);
    const header = lines.shift().split(',').map(s=>s.trim().toLowerCase());
    const idx = Object.fromEntries(header.map((h,i)=>[h,i]));
    return lines.map(line=>{
      const cells = line.split(',').map(s=>s.trim());
      return {
        frame: Number(cells[idx['frame']]||cells[0]||0),
        headline: cells[idx['headline']] || '',
        subhead: cells[idx['subhead']] || ''
      };
    }).sort((a,b)=>a.frame-b.frame);
  }catch(_){ return []; }
}

function dims(p){
  const out = sh(`magick identify -format "%w %h" "${p}"`);
  const [w,h] = out.trim().split(/\s+/).map(n=>parseInt(n,10));
  return { w, h };
}

function one(input, output, headline, subhead){
  const { w, h } = dims(input);
  const panelH = Math.round(h * (PANEL/100));
  const headPt = Math.max(24, Math.round(h * (HEAD_PCT/100)));
  const subPt  = Math.max(18, Math.round(h * (SUB_PCT/100)));
  const textX = PAD;
  const headY = Math.round(h - panelH + PAD*0.6 + headPt*0.1);
  const subY  = Math.round(headY + headPt + Math.max(12, headPt*0.25));

  const cmd = [
    `magick "${input}"`,
    `\\( -size ${w}x${panelH} xc:none -fill "${PANEL_COLOR}" -draw "rectangle 0,0 ${w},${panelH}" \\)`,
    `-gravity south -compose over -composite`,
    `-gravity northwest -font "${FONT}" -fill "${COLOR_H}" -pointsize ${headPt} -annotate +${textX}+${headY} "${headline.replace(/"/g,'\\\"')}"`,
    `-gravity northwest -font "${FONT}" -fill "${COLOR_S}" -pointsize ${subPt} -annotate +${textX}+${subY} "${subhead.replace(/"/g,'\\\"')}"`,
    `"${output}"`
  ].join(' ');

  if (DRY) {
    console.log('DRY:', cmd);
  } else {
    sh(cmd);
  }
}

let report = { locales: {}, panelPct: PANEL, font: FONT };
for(const loc of LOCALES){
  const overlaysCsv = path.join(OVERLAYS_DIR, `overlays_${loc}.csv`);
  const overlays = readCSV(overlaysCsv);
  report.locales[loc] = { overlays: overlays.length, files: [] };

  if (PLATFORM==='ios' || PLATFORM==='both'){
    const in1 = path.join('fastlane','_raw','ios',loc);
    const in2 = path.join('fastlane','screenshots',loc);
    const inputDir = listImages(in1).length ? in1 : in2;
    const outDir = path.join(RENDERED_DIR, 'ios', loc);
    ensureDir(outDir);
    const files = listImages(inputDir).sort();
    files.forEach((src,i)=>{
      const ov = overlays[i] || { headline:'', subhead:'' };
      const dst = path.join(outDir, Path.basename(src));
      one(src, dst, ov.headline || '', ov.subhead || '');
      report.locales[loc].files.push({ platform:'ios', src, dst });
    });
  }
  if (PLATFORM==='android' || PLATFORM==='both'){
    const in1 = path.join('fastlane','_raw','android',loc,'phone');
    const in2 = path.join('fastlane','metadata','android',loc,'phoneScreenshots');
    const inputDir = listImages(in1).length ? in1 : in2;
    const outDir = path.join(RENDERED_DIR, 'android', loc, 'phone');
    ensureDir(outDir);
    const files = listImages(inputDir).sort();
    files.forEach((src,i)=>{
      const ov = overlays[i] || { headline:'', subhead:'' };
      const dst = path.join(outDir, Path.basename(src));
      one(src, dst, ov.headline || '', ov.subhead || '');
      report.locales[loc].files.push({ platform:'android', src, dst });
    });
  }
}

try{ fs.writeFileSync('tools/overlay_render_report.json', JSON.stringify(report,null,2)); }catch(_){}
console.log('Overlay rendering complete.');
process.exit(0);
