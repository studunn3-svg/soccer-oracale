# soccer-oracle

This repository is prepared for manual upload to GitHub.

## How to push manually

```bash
git init
git branch -m main
git add .
git commit -m "Initial import: Soccer Oracle"
# Create a GitHub repo named 'soccer-oracle' and then:
git remote add origin git@github.com:<your-username>/soccer-oracle.git
git push -u origin main
```

See `SETUP.md` and `.github/workflows/` for CI/EAS build instructions.
