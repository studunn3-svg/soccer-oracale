# Soccer Oracle — BUILD & DEPLOY Quickstart

See `.github/workflows/validate.yml` and `.github/workflows/build_mobile.yml` for CI.
For local builds, follow mobile/BUILDING.md if present.
