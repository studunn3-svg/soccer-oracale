# Soccer Oracle — App Store Metadata (iOS)

**Name:** Soccer Oracle — AI Football Predictions  
**Subtitle:** International fixtures, AI insights & model lab  
**Bundle ID:** app.socceroracle  

## Description
Soccer Oracle is an AI-powered football intelligence companion.  
Explore upcoming fixtures, compare international teams, simulate tournaments and dive into a full
Model Lab that tracks prediction accuracy, evolution, stability and confidence calibration.

- AI-powered predictions for major leagues and international competitions  
- International team radar charts (attack, defence, stars, ranking)  
- Head-to-head engine for quick country comparisons  
- Tournament simulator for EUROs and World Cups (mock data to start)  
- Model Accuracy dashboard with competition breakdowns  
- Evolution Log showing how the AI has improved over versions  
- Version Comparison, Stability Index and Confidence Heatmap  
- ROI Simulator (hypothetical, educational only — Soccer Oracle does not facilitate betting)  

## Keywords
football, soccer, predictions, stats, AI, analytics, international, EURO, World Cup, fixtures, model lab

## Promotional Text
AI-powered football intelligence with international focus, model transparency and premium analysis tools.

## Support URL
https://socceroracle.app/support (placeholder)

## Marketing URL
https://socceroracle.app (placeholder)

