# Soccer Oracle — Play Store Listing (Android)

**Title:** Soccer Oracle — AI Football Predictions  
**Short Description:** AI-powered football insights, international fixtures & model accuracy lab.  
**Package:** app.socceroracle  

## Full Description
Soccer Oracle brings together AI, football data and clear visual insights.

See upcoming international fixtures, compare national teams on radar charts, simulate tournaments and
open the AI Model Lab to understand how the prediction engine performs over time.

Highlights:
- AI insights for leagues and international competitions  
- Team strength radar charts with attack, defence, stars and ranking  
- Head-to-head comparison engine for international teams  
- Tournament bracket viewer and AI tournament simulator  
- Model Accuracy, Evolution and Version Comparison views  
- Stability Index and Confidence Heatmap for calibration transparency  
- ROI Simulator for educational what-if analysis  

Soccer Oracle does **not** process bets or link to bookmakers. All projections are informational only.

## Tags (internal)
Sports, Football, Analytics, AI, Data

## Privacy Policy URL
https://socceroracle.app/privacy (placeholder)

## Terms of Use URL
https://socceroracle.app/terms (placeholder)

