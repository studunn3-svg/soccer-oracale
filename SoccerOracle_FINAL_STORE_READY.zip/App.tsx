import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './src/screens/HomeScreen';
import InternationalFixturesScreen from './src/screens/InternationalFixturesScreen';
import InternationalTeamScreen from './src/screens/InternationalTeamScreen';
import HeadToHeadScreen from './src/screens/HeadToHeadScreen';
import PowerRankingScreen from './src/screens/PowerRankingScreen';
import TournamentBracketScreen from './src/screens/TournamentBracketScreen';
import TournamentSimulatorScreen from './src/screens/TournamentSimulatorScreen';
import PlayerDetailScreen from './src/screens/PlayerDetailScreen';
import ModelAccuracyScreen from './src/screens/ModelAccuracyScreen';
import ModelEvolutionScreen from './src/screens/ModelEvolutionScreen';
import ModelVersionComparisonScreen from './src/screens/ModelVersionComparisonScreen';
import AccuracyForecastScreen from './src/screens/AccuracyForecastScreen';
import ModelAnatomyScreen from './src/screens/ModelAnatomyScreen';
import ModelStabilityScreen from './src/screens/ModelStabilityScreen';
import ROISimulatorScreen from './src/screens/ROISimulatorScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import PaywallScreen from './src/screens/PaywallScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: '#050B16' },
          headerTintColor: '#fff',
        }}
      >
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Soccer Oracle' }} />
        <Stack.Screen name="InternationalFixtures" component={InternationalFixturesScreen} options={{ title: 'International Fixtures' }} />
        <Stack.Screen name="InternationalTeam" component={InternationalTeamScreen} options={{ title: 'International Team' }} />
        <Stack.Screen name="H2H" component={HeadToHeadScreen} options={{ title: 'Head to Head' }} />
        <Stack.Screen name="PowerRankings" component={PowerRankingScreen} options={{ title: 'Power Rankings' }} />
        <Stack.Screen name="TournamentBracket" component={TournamentBracketScreen} options={{ title: 'Tournament Bracket' }} />
        <Stack.Screen name="TournamentSimulator" component={TournamentSimulatorScreen} options={{ title: 'Tournament Simulator' }} />
        <Stack.Screen name="PlayerDetail" component={PlayerDetailScreen} options={{ title: 'Player Detail' }} />
        <Stack.Screen name="ModelAccuracy" component={ModelAccuracyScreen} options={{ title: 'Model Accuracy' }} />
        <Stack.Screen name="ModelEvolution" component={ModelEvolutionScreen} options={{ title: 'Model Evolution' }} />
        <Stack.Screen name="ModelVersionComparison" component={ModelVersionComparisonScreen} options={{ title: 'Version Comparison' }} />
        <Stack.Screen name="AccuracyForecast" component={AccuracyForecastScreen} options={{ title: 'Accuracy Forecast' }} />
        <Stack.Screen name="ModelAnatomy" component={ModelAnatomyScreen} options={{ title: 'Model Anatomy' }} />
        <Stack.Screen name="ModelStability" component={ModelStabilityScreen} options={{ title: 'Model Stability' }} />
        <Stack.Screen name="ROISimulator" component={ROISimulatorScreen} options={{ title: 'ROI Simulator' }} />
        <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: 'Settings' }} />
        <Stack.Screen name="Paywall" component={PaywallScreen} options={{ title: 'Go Premium' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
