import React from 'react';
import { View, Text } from 'react-native';
import RadarChart from './RadarChart';
import type { PlayerStats } from '../data/players.mock';

function avgForm(form: string[]): number {
  if (!form.length) return 0;
  const nums = form.map((f) => parseFloat(f));
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

export default function PlayerRadarCard({ player }: { player: PlayerStats }) {
  const minutesPer90 = player.minutes / 90 || 1;
  const tacklesPer90 = player.tackles / minutesPer90;
  const cardsPer90 = (player.yellowCards + player.redCards * 2) / minutesPer90;
  const goalsPer90 = player.goals / minutesPer90;
  const assistsPer90 = player.assists / minutesPer90;
  const formScore = avgForm(player.form);

  const norm = (v: number, max: number) => Math.min(100, Math.round((v / max) * 100));

  const values = [
    norm(goalsPer90, 1.0),
    norm(assistsPer90, 1.0),
    norm(tacklesPer90, 4.0),
    norm(cardsPer90, 1.0),
    player.passCompletion,
    norm(formScore, 10.0),
    norm(player.rating, 10.0),
  ];

  const labels = ['Goals', 'Assists', 'Tackles', 'Cards', 'Passing', 'Form', 'Rating'];

  return (
    <View
      style={{
        backgroundColor: '#112A45',
        padding: 16,
        borderRadius: 12,
        marginBottom: 20,
      }}
    >
      <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700', marginBottom: 10 }}>
        Player Radar
      </Text>
      <RadarChart values={values} labels={labels} size={260} />
      <Text style={{ color: '#9FB2CF', marginTop: 10 }}>
        Goals/90: {goalsPer90.toFixed(2)} • Assists/90: {assistsPer90.toFixed(2)} • Tackles/90:{' '}
        {tacklesPer90.toFixed(2)}
      </Text>
    </View>
  );
}
