// placeholder card
export default function C(){return null;}