import React from 'react';
import { View } from 'react-native';
import Svg, { Polygon, Text as SvgText } from 'react-native-svg';

type Props = {
  values: number[];
  labels: string[];
  size?: number;
};

export default function RadarChart({ values, labels, size = 260 }: Props) {
  const radius = size / 2;
  const step = (2 * Math.PI) / values.length;

  const clamp = (v: number) => Math.max(0, Math.min(100, v));

  const points = values.map((v, i) => {
    const angle = i * step - Math.PI / 2;
    const r = radius * (clamp(v) / 100);
    return `${radius + r * Math.cos(angle)},${radius + r * Math.sin(angle)}`;
  });

  const grid = [20, 40, 60, 80, 100];

  return (
    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
      <Svg height={size} width={size}>
        {grid.map((g, i) => (
          <Polygon
            key={i}
            points={values
              .map((_, j) => {
                const angle = j * step - Math.PI / 2;
                const r = radius * (g / 100);
                return `${radius + r * Math.cos(angle)},${radius + r * Math.sin(angle)}`;
              })
              .join(' ')}
            stroke="#24496E"
            strokeWidth={1}
            fill="none"
          />
        ))}
        <Polygon
          points={points.join(' ')}
          fill="rgba(90,184,255,0.3)"
          stroke="#5AB8FF"
          strokeWidth={2}
        />
        {labels.map((label, i) => {
          const angle = i * step - Math.PI / 2;
          const x = radius + radius * Math.cos(angle);
          const y = radius + radius * Math.sin(angle);
          return (
            <SvgText
              key={i}
              x={x}
              y={y}
              fill="#9FB2CF"
              fontSize={10}
              textAnchor="middle"
            >
              {label}
            </SvgText>
          );
        })}
      </Svg>
    </View>
  );
}
