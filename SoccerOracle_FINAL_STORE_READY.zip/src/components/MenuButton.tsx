import React from 'react';
import { Pressable, Text, View, StyleSheet } from 'react-native';

type Props = {
  label: string;
  onPress: () => void;
  accent?: boolean;
};

export default function MenuButton({ label, onPress, accent }: Props) {
  return (
    <Pressable onPress={onPress} style={[styles.button, accent && styles.accent]}>
      <View>
        <Text style={styles.label}>{label}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#102846',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 10,
  },
  accent: {
    borderWidth: 1,
    borderColor: '#FFD700',
  },
  label: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});
