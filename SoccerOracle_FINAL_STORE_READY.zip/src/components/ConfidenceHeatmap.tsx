import React from 'react';
import { View, Text } from 'react-native';

type Bucket = { bucket: string; accuracy: number };

export default function ConfidenceHeatmap({ buckets }: { buckets: Bucket[] }) {
  return (
    <View style={{ marginTop: 8 }}>
      {buckets.map((b, i) => {
        const intensity = Math.min(1, b.accuracy / 80);
        const bgOpacity = 0.2 + intensity * 0.6;
        const bg = `rgba(90,184,255,${bgOpacity})`;
        return (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
            <View
              style={{
                width: 120,
                paddingVertical: 6,
                paddingHorizontal: 8,
                backgroundColor: '#10223B',
                borderRadius: 8,
                marginRight: 8,
              }}
            >
              <Text style={{ color: '#9FB2CF', fontSize: 12 }}>{b.bucket}</Text>
            </View>
            <View
              style={{
                flex: 1,
                height: 24,
                borderRadius: 6,
                backgroundColor: '#0F1F2E',
                overflow: 'hidden',
              }}
            >
              <View
                style={{
                  width: `${b.accuracy}%`,
                  height: '100%',
                  backgroundColor: bg,
                  justifyContent: 'center',
                  paddingHorizontal: 6,
                }}
              >
                <Text style={{ color: '#fff', fontSize: 12 }}>{b.accuracy}%</Text>
              </View>
            </View>
          </View>
        );
      })}
    </View>
  );
}
