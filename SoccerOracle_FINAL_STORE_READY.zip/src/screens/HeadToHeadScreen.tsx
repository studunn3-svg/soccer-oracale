import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { computeH2H, H2HOutput } from '../lib/h2h';
import { getTeamProfile } from '../lib/internationalTeam';

export default function HeadToHeadScreen({ route }: any) {
  const { homeIso, awayIso } = route.params;
  const [homeTeam, setHomeTeam] = useState<any>(null);
  const [awayTeam, setAwayTeam] = useState<any>(null);
  const [h2h, setH2H] = useState<H2HOutput | null>(null);

  useEffect(() => {
    (async () => {
      const home = await getTeamProfile(homeIso);
      const away = await getTeamProfile(awayIso);
      setHomeTeam(home);
      setAwayTeam(away);
      const result = await computeH2H(homeIso, awayIso);
      setH2H(result);
    })();
  }, [homeIso, awayIso]);

  if (!homeTeam || !awayTeam || !h2h) {
    return (
      <View style={{ flex: 1, backgroundColor: '#0B1727', justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ color: '#fff' }}>Loading comparison...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 24, fontWeight: '700', marginBottom: 14 }}>
          Head-to-Head Comparison
        </Text>
        <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>
          {homeTeam.name} {h2h.scoreHome} — {h2h.scoreAway} {awayTeam.name}
        </Text>
        <Text style={{ color: '#9FB2CF', marginTop: 8 }}>
          Confidence Gap: {h2h.confidenceGap}
        </Text>
        <Text style={{ color: '#fff', fontSize: 20, fontWeight: '700', marginTop: 20, marginBottom: 10 }}>
          Key Factors
        </Text>
        {h2h.reasons.map((reason, i) => (
          <View key={i} style={{ marginBottom: 8 }}>
            <Text style={{ color: '#C7D3E3' }}>• {reason}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
