import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { MODEL_ACCURACY_DATA as A } from '../data/modelAccuracy.mock';
import ConfidenceHeatmap from '../components/ConfidenceHeatmap';

export default function ModelAccuracyScreen() {
  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: '700', marginBottom: 16 }}>
          Model Accuracy
        </Text>
        <View
          style={{
            backgroundColor: '#112A45',
            padding: 20,
            borderRadius: 12,
            marginBottom: 20,
          }}
        >
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>
            Global Prediction Accuracy
          </Text>
          <Text style={{ color: '#5AB8FF', fontSize: 42, fontWeight: '800', marginTop: 6 }}>
            {A.globalAccuracy}%
          </Text>
          <Text style={{ color: '#9FB2CF', marginTop: 10 }}>
            Last 3 days: {A.last3Days}% • Last 7 days: {A.last7Days}% • Last 30 days: {A.last30Days}%
          </Text>
        </View>

        <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700', marginBottom: 10 }}>
          Accuracy by Competition
        </Text>
        {A.byCompetition.map((c, i) => (
          <View
            key={i}
            style={{
              backgroundColor: '#102846',
              padding: 12,
              borderRadius: 10,
              marginBottom: 10,
            }}
          >
            <Text style={{ color: '#fff', fontSize: 16 }}>{c.name}</Text>
            <Text style={{ color: '#5AB8FF', marginTop: 4, fontWeight: '700' }}>
              {c.accuracy}%
            </Text>
          </View>
        ))}

        <View
          style={{
            backgroundColor: '#112A45',
            padding: 16,
            borderRadius: 12,
            marginTop: 20,
            marginBottom: 20,
          }}
        >
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700', marginBottom: 8 }}>
            Confidence Calibration
          </Text>
          <ConfidenceHeatmap buckets={A.confidenceBuckets} />
        </View>
      </ScrollView>
    </View>
  );
}
