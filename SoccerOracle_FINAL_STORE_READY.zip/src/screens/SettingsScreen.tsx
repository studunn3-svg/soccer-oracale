
import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import i18n from '../lib/i18n';

const languages = [
  { code: 'en-US', label: 'English (US)', flag: '🇺🇸' },
  { code: 'en-GB', label: 'English (UK)', flag: '🇬🇧' },
  { code: 'es-ES', label: 'Español', flag: '🇪🇸' },
  { code: 'fr-FR', label: 'Français', flag: '🇫🇷' },
  { code: 'de-DE', label: 'Deutsch', flag: '🇩🇪' },
  { code: 'it-IT', label: 'Italiano', flag: '🇮🇹' }
];

export default function SettingsScreen() {
  const [lang, setLang] = useState(i18n.locale);

  const changeLang = (code: string) => {
    i18n.locale = code;
    setLang(code);
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#050B16' }}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Text style={{ color: '#FFD700', fontSize: 24, marginBottom: 20 }}>
          Settings
        </Text>

        <Text style={{ color: '#5AB8FF', fontSize: 18, marginBottom: 12 }}>
          Language
        </Text>

        {languages.map((l) => (
          <Pressable
            key={l.code}
            onPress={() => changeLang(l.code)}
            style={{
              padding: 12,
              marginBottom: 8,
              backgroundColor: l.code === lang ? '#102846' : '#0A1626',
              borderRadius: 10
            }}
          >
            <Text style={{ color: '#fff', fontSize: 16 }}>
              {l.flag}  {l.label}
            </Text>
          </Pressable>
        ))}

      </ScrollView>
    </View>
  );
}
