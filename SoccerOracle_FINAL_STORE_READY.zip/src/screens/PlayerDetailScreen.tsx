import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { MOCK_PLAYERS, PlayerStats } from '../data/players.mock';
import PlayerRadarCard from '../components/PlayerRadarCard';

export default function PlayerDetailScreen({ route }: any) {
  const { playerId } = route.params;
  const [player, setPlayer] = useState<PlayerStats | null>(null);

  useEffect(() => {
    const found = MOCK_PLAYERS.find((p) => p.id === playerId);
    setPlayer(found || MOCK_PLAYERS[0]);
  }, [playerId]);

  if (!player) {
    return (
      <View style={{ flex: 1, backgroundColor: '#0B1727', justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ color: '#fff' }}>Loading player...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 24, fontWeight: '700' }}>{player.name}</Text>
        <Text style={{ color: '#9FB2CF', marginBottom: 12 }}>
          {player.position} • {player.club}
        </Text>
        <PlayerRadarCard player={player} />
      </ScrollView>
    </View>
  );
}
