import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { MODEL_EVOLUTION_LOG as LOG } from '../data/modelEvolution.mock';

export default function ModelEvolutionScreen() {
  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: '700', marginBottom: 20 }}>
          AI Evolution Log
        </Text>
        {LOG.map((entry, i) => (
          <View
            key={i}
            style={{
              backgroundColor: '#112A45',
              padding: 16,
              borderRadius: 12,
              marginBottom: 20,
              borderLeftWidth: 4,
              borderLeftColor: '#5AB8FF',
            }}
          >
            <Text style={{ color: '#5AB8FF', fontSize: 12 }}>{entry.date}</Text>
            <Text
              style={{
                color: '#fff',
                fontSize: 20,
                fontWeight: '700',
                marginTop: 4,
              }}
            >
              Version {entry.version}
            </Text>
            <Text style={{ color: '#9FB2CF', marginTop: 10, fontSize: 16, fontWeight: '600' }}>
              Key Improvements
            </Text>
            {entry.improvements.map((p: string, idx: number) => (
              <Text key={idx} style={{ color: '#C7D3E3', marginTop: 4 }}>
                • {p}
              </Text>
            ))}
            <View
              style={{
                backgroundColor: '#102846',
                padding: 10,
                borderRadius: 8,
                marginTop: 14,
              }}
            >
              <Text style={{ color: '#fff', fontSize: 16, fontWeight: '700' }}>
                Accuracy Improvement
              </Text>
              <Text style={{ color: '#5AB8FF', marginTop: 4 }}>
                {entry.accuracyBefore}% → {entry.accuracyAfter}% (+{entry.accuracyAfter - entry.accuracyBefore}%)
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
