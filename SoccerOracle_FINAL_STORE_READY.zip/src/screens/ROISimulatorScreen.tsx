import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, Pressable } from 'react-native';

export default function ROISimulatorScreen() {
  const [hitRate, setHitRate] = useState('0.71');
  const [avgOdds, setAvgOdds] = useState('1.90');
  const [stake, setStake] = useState('10');
  const [bets, setBets] = useState('100');
  const [result, setResult] = useState<any>(null);

  const onSimulate = () => {
    const h = Math.max(0, Math.min(1, parseFloat(hitRate) || 0));
    const o = parseFloat(avgOdds) || 1.0;
    const s = parseFloat(stake) || 0;
    const n = parseInt(bets, 10) || 0;

    const wins = h * n;
    const totalStaked = n * s;
    const totalReturned = wins * s * o;
    const netProfit = totalReturned - totalStaked;
    const roi = totalStaked > 0 ? (netProfit / totalStaked) * 100 : 0;

    setResult({
      totalStaked: Math.round(totalStaked),
      totalReturned: Math.round(totalReturned),
      netProfit: Math.round(netProfit),
      roi: Math.round(roi),
    });
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 26, fontWeight: '700', marginBottom: 12 }}>
          ROI Simulator (Hypothetical)
        </Text>
        <Text style={{ color: '#9FB2CF', marginBottom: 16, fontSize: 12 }}>
          This tool is for educational and illustrative purposes only. It does not constitute
          financial or gambling advice, and Soccer Oracle does not facilitate betting.
        </Text>

        <View
          style={{
            backgroundColor: '#112A45',
            padding: 16,
            borderRadius: 12,
            marginBottom: 16,
          }}
        >
          <Text style={{ color: '#fff', marginBottom: 6 }}>Hit-rate (0–1)</Text>
          <TextInput
            value={hitRate}
            onChangeText={setHitRate}
            keyboardType="decimal-pad"
            style={{
              backgroundColor: '#0F1F35',
              color: '#fff',
              padding: 8,
              borderRadius: 6,
              marginBottom: 10,
            }}
          />
          <Text style={{ color: '#fff', marginBottom: 6 }}>Average odds (decimal)</Text>
          <TextInput
            value={avgOdds}
            onChangeText={setAvgOdds}
            keyboardType="decimal-pad"
            style={{
              backgroundColor: '#0F1F35',
              color: '#fff',
              padding: 8,
              borderRadius: 6,
              marginBottom: 10,
            }}
          />
          <Text style={{ color: '#fff', marginBottom: 6 }}>Stake per pick (units)</Text>
          <TextInput
            value={stake}
            onChangeText={setStake}
            keyboardType="decimal-pad"
            style={{
              backgroundColor: '#0F1F35',
              color: '#fff',
              padding: 8,
              borderRadius: 6,
              marginBottom: 10,
            }}
          />
          <Text style={{ color: '#fff', marginBottom: 6 }}>Number of picks</Text>
          <TextInput
            value={bets}
            onChangeText={setBets}
            keyboardType="number-pad"
            style={{
              backgroundColor: '#0F1F35',
              color: '#fff',
              padding: 8,
              borderRadius: 6,
              marginBottom: 12,
            }}
          />
          <Pressable
            onPress={onSimulate}
            style={{
              backgroundColor: '#1F5DA1',
              paddingVertical: 10,
              borderRadius: 8,
              alignItems: 'center',
            }}
          >
            <Text style={{ color: '#fff', fontSize: 16, fontWeight: '700' }}>
              Run Hypothetical Simulation
            </Text>
          </Pressable>
        </View>

        {result && (
          <View
            style={{
              backgroundColor: '#112A45',
              padding: 16,
              borderRadius: 12,
              marginBottom: 24,
            }}
          >
            <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700', marginBottom: 8 }}>
              Simulation Result
            </Text>
            <Text style={{ color: '#9FB2CF' }}>Total Staked: {result.totalStaked} units</Text>
            <Text style={{ color: '#9FB2CF', marginTop: 4 }}>
              Total Returned: {result.totalReturned} units
            </Text>
            <Text
              style={{
                color: result.netProfit >= 0 ? '#27D97D' : '#FF5B5B',
                marginTop: 4,
              }}
            >
              Net Result: {result.netProfit >= 0 ? '+' : ''}
              {result.netProfit} units
            </Text>
            <Text
              style={{
                color: result.roi >= 0 ? '#27D97D' : '#FF5B5B',
                marginTop: 4,
                fontWeight: '700',
              }}
            >
              ROI: {result.roi >= 0 ? '+' : ''}
              {result.roi}%
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
