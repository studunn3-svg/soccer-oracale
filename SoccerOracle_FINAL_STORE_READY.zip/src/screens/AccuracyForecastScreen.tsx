import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { forecastNextAccuracy, ForecastPoint } from '../lib/accuracyForecast';
import { MODEL_VERSION_COMPARISON as DATA } from '../data/modelVersionComparison.mock';

export default function AccuracyForecastScreen() {
  const [forecast, setForecast] = useState<ForecastPoint[]>([]);

  useEffect(() => {
    setForecast(forecastNextAccuracy(3));
  }, []);

  const last = DATA[DATA.length - 1];

  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: '700', marginBottom: 20 }}>
          Accuracy Forecast
        </Text>
        <View
          style={{
            backgroundColor: '#112A45',
            padding: 16,
            borderRadius: 12,
            marginBottom: 20,
          }}
        >
          <Text style={{ color: '#5AB8FF', fontSize: 14 }}>
            Current Version ({last.version})
          </Text>
          <Text style={{ color: '#fff', fontSize: 36, fontWeight: '800' }}>
            {last.global}%
          </Text>
          <Text style={{ color: '#9FB2CF', marginTop: 4 }}>
            Confidence Error: {last.avgConfidenceError}%
          </Text>
        </View>

        {forecast.map((f, i) => (
          <View
            key={i}
            style={{
              backgroundColor: '#102846',
              padding: 16,
              borderRadius: 12,
              marginBottom: 12,
            }}
          >
            <Text style={{ color: '#5AB8FF', fontSize: 14 }}>{f.versionName}</Text>
            <Text style={{ color: '#fff', fontSize: 26, fontWeight: '800', marginTop: 4 }}>
              Predicted Accuracy: {f.predictedAccuracy}%
            </Text>
            <Text style={{ color: '#9FB2CF', marginTop: 6 }}>
              Projected Confidence Error: {f.predictedConfidenceError}%
            </Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
