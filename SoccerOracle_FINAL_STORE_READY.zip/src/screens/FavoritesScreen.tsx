// Placeholder Favorites
export default function Favorites(){return null;}