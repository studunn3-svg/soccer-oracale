import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { PLANS, purchasePlan, restorePurchases } from '../lib/subscriptions';

export default function PaywallScreen() {
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);

  const onSelectPlan = async (planId: string) => {
    setLoadingPlan(planId);
    try {
      const res = await purchasePlan(planId);
      if (res.success) {
        Alert.alert('Premium unlocked (mock)', 'In production this would unlock your Premium features.');
      } else {
        Alert.alert('Purchase failed', 'Please try again.');
      }
    } finally {
      setLoadingPlan(null);
    }
  };

  const onRestore = async () => {
    const res = await restorePurchases();
    if (res.success) {
      Alert.alert('Purchases restored (mock)', 'In production this would sync your Premium access.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#050B16' }}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Text style={{ color: '#FFD700', fontSize: 14, fontWeight: '700', marginBottom: 8 }}>
          SOCCER ORACLE PREMIUM
        </Text>
        <Text style={{ color: '#fff', fontSize: 26, fontWeight: '800', marginBottom: 8 }}>
          Unlock the full AI Suite
        </Text>
        <Text style={{ color: '#9FB2CF', marginBottom: 20 }}>
          Get deeper international insights, full Model Lab analytics, AI explanations, tournament
          simulations and more.
        </Text>

        {PLANS.map((p) => (
          <Pressable
            key={p.id}
            onPress={() => onSelectPlan(p.id)}
            style={{
              backgroundColor: '#102846',
              padding: 16,
              borderRadius: 12,
              marginBottom: 12,
              borderWidth: p.period === 'YEARLY' ? 1 : 0,
              borderColor: p.period === 'YEARLY' ? '#FFD700' : 'transparent',
            }}
          >
            <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>{p.name}</Text>
            <Text style={{ color: '#5AB8FF', marginTop: 4 }}>{p.price}</Text>
            {p.highlight && (
              <Text style={{ color: '#C7D3E3', marginTop: 4 }}>{p.highlight}</Text>
            )}
            {loadingPlan === p.id && (
              <Text style={{ color: '#9FB2CF', marginTop: 6 }}>Processing...</Text>
            )}
          </Pressable>
        ))}

        <Pressable onPress={onRestore} style={{ marginTop: 16 }}>
          <Text style={{ color: '#5AB8FF' }}>Restore purchases</Text>
        </Pressable>

        <Text style={{ color: '#6D7D93', fontSize: 11, marginTop: 20 }}>
          Payment, subscription and trial handling will be managed via the App Store / Play Store and
          RevenueCat in production. This screen is wired as a visual paywall with mock logic.
        </Text>
      </ScrollView>
    </View>
  );
}
