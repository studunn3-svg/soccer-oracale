import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { computeGlobalPowerRanking, RankedNation } from '../lib/powerRanking';

export default function PowerRankingScreen() {
  const [rankings, setRankings] = useState<RankedNation[]>([]);

  useEffect(() => {
    (async () => {
      const data = await computeGlobalPowerRanking();
      setRankings(data);
    })();
  }, []);

  return (
    <View style={{ backgroundColor: '#0B1727', flex: 1 }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 26, fontWeight: '700', marginBottom: 20 }}>
          Global Power Rankings
        </Text>
        {rankings.map((t, i) => (
          <View
            key={i}
            style={{
              backgroundColor: '#102846',
              padding: 12,
              borderRadius: 12,
              marginBottom: 12,
              flexDirection: 'row',
              alignItems: 'center',
            }}
          >
            <Text style={{ color: '#5AB8FF', fontSize: 24, fontWeight: '800', width: 40 }}>
              {i + 1}
            </Text>
            <View style={{ flex: 1 }}>
              <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>{t.name}</Text>
              <Text style={{ color: '#9FB2CF' }}>
                {t.confed} • Score: {t.score}
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
