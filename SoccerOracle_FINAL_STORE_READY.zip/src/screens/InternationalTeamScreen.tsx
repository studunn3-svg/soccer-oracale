import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { getTeamProfile } from '../lib/internationalTeam';
import RadarChart from '../components/RadarChart';
import type { InternationalTeam } from '../data/internationalTeams.mock';

export default function InternationalTeamScreen({ route }: any) {
  const { iso } = route.params;
  const [team, setTeam] = useState<InternationalTeam | null>(null);

  useEffect(() => {
    (async () => {
      const data = await getTeamProfile(iso);
      setTeam(data);
    })();
  }, [iso]);

  if (!team) {
    return (
      <View style={{ flex: 1, backgroundColor: '#0B1727', justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ color: '#fff' }}>Loading team...</Text>
      </View>
    );
  }

  const values = [
    team.goalsFor * 10,
    team.cleanSheets * 10,
    team.goalsAgainst * -5 + 100,
    team.starPlayers.length * 20,
    200 - team.fifaRanking,
  ];

  const labels = ['Attack', 'Defence', 'Conceding', 'Stars', 'Ranking'];

  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 26, fontWeight: '700', marginBottom: 10 }}>
          {team.name}
        </Text>
        <Text style={{ color: '#7FA3C8', marginBottom: 12 }}>
          Confederation: {team.confederation} • FIFA Ranking: {team.fifaRanking}
        </Text>

        <View
          style={{
            backgroundColor: '#112A45',
            padding: 16,
            borderRadius: 12,
            marginBottom: 20,
          }}
        >
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700', marginBottom: 16 }}>
            Team Radar
          </Text>
          <RadarChart values={values} labels={labels} size={260} />
        </View>

        <View
          style={{
            backgroundColor: '#112A45',
            padding: 16,
            borderRadius: 12,
            marginBottom: 20,
          }}
        >
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>Stats</Text>
          <Text style={{ color: '#9FB2CF', marginTop: 10 }}>Goals For: {team.goalsFor}</Text>
          <Text style={{ color: '#9FB2CF', marginTop: 4 }}>Goals Against: {team.goalsAgainst}</Text>
          <Text style={{ color: '#9FB2CF', marginTop: 4 }}>Clean Sheets: {team.cleanSheets}</Text>
        </View>
      </ScrollView>
    </View>
  );
}
