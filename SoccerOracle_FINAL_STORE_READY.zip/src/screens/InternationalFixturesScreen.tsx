import React, { useEffect, useState, useMemo } from 'react';
import { View, Text, ScrollView, Pressable, TextInput } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { getInternationalFixtures } from '../lib/internationalFixtures';
import type { InternationalFixture } from '../data/internationalFixtures.mock';

const FILTERS = [
  { key: 'ALL', label: 'All' },
  { key: 'EURO_QUALIFIER', label: 'EURO' },
  { key: 'AFCON', label: 'AFCON' },
  { key: 'FRIENDLY', label: 'Friendlies' },
];

export default function InternationalFixturesScreen() {
  const nav: any = useNavigation();
  const [fixtures, setFixtures] = useState<InternationalFixture[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('ALL');
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      const data = await getInternationalFixtures();
      setFixtures(data);
    })();
  }, []);

  const visibleFixtures = useMemo(() => {
    let list = [...fixtures];
    if (filter !== 'ALL') {
      list = list.filter((f) => f.competition === filter);
    }
    if (search.trim().length > 0) {
      const q = search.toLowerCase();
      list = list.filter(
        (f) =>
          f.homeTeam.toLowerCase().includes(q) ||
          f.awayTeam.toLowerCase().includes(q) ||
          f.competitionName.toLowerCase().includes(q),
      );
    }
    return list.sort(
      (a, b) => new Date(a.kickoffISO).getTime() - new Date(b.kickoffISO).getTime(),
    );
  }, [fixtures, filter, search]);

  const toggleOpen = (id: string) => setOpenId((prev) => (prev === id ? null : id));

  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ maxHeight: 50 }}
        contentContainerStyle={{ paddingHorizontal: 12, paddingVertical: 10 }}
      >
        {FILTERS.map((f) => {
          const selected = f.key === filter;
          return (
            <Pressable
              key={f.key}
              onPress={() => setFilter(f.key)}
              style={{
                paddingVertical: 6,
                paddingHorizontal: 14,
                borderRadius: 18,
                marginRight: 10,
                backgroundColor: selected ? '#1F5DA1' : '#0E2A45',
              }}
            >
              <Text
                style={{
                  color: selected ? '#fff' : '#91A9C4',
                  fontSize: 14,
                  fontWeight: selected ? '700' : '500',
                }}
              >
                {f.label}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <View style={{ padding: 16, paddingBottom: 0 }}>
        <TextInput
          placeholder="Search countries, teams, competitions..."
          placeholderTextColor="#6D7D93"
          value={search}
          onChangeText={setSearch}
          style={{
            backgroundColor: '#0F1F35',
            color: '#fff',
            padding: 12,
            borderRadius: 8,
            fontSize: 14,
          }}
        />
      </View>

      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 22, fontWeight: '700', marginBottom: 12 }}>
          International Fixtures
        </Text>

        {visibleFixtures.map((f) => {
          const isOpen = openId === f.id;
          const confPct = f.confidence ? Math.round(f.confidence * 100) : undefined;
          return (
            <View
              key={f.id}
              style={{
                backgroundColor: '#102846',
                padding: 12,
                borderRadius: 12,
                marginBottom: 14,
              }}
            >
              <View
                style={{
                  backgroundColor: '#1F5DA1',
                  paddingVertical: 3,
                  paddingHorizontal: 8,
                  alignSelf: 'flex-start',
                  borderRadius: 6,
                  marginBottom: 6,
                }}
              >
                <Text style={{ color: '#fff', fontSize: 11 }}>{f.competitionName}</Text>
              </View>

              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600' }}>
                  {f.homeTeam}
                </Text>
                <Text style={{ color: '#9FB2CF', marginHorizontal: 6 }}>vs</Text>
                <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600' }}>
                  {f.awayTeam}
                </Text>
              </View>

              <Text style={{ color: '#9FB2CF', fontSize: 12, marginTop: 4 }}>
                {new Date(f.kickoffISO).toUTCString()}
              </Text>

              {f.predictedOutcome && (
                <Text style={{ color: '#C7D3E3', marginTop: 6 }}>
                  Predicted: {f.predictedOutcome}{' '}
                  {confPct !== undefined ? `— ${confPct}%` : ''}
                </Text>
              )}

              <View
                style={{
                  flexDirection: 'row',
                  marginTop: 10,
                  justifyContent: 'space-between',
                }}
              >
                <Pressable onPress={() => toggleOpen(f.id)}>
                  <Text style={{ color: '#5AB8FF' }}>
                    {isOpen ? 'Hide “Why?”' : 'Why does the Oracle think this?'}
                  </Text>
                </Pressable>
                <Pressable
                  onPress={() =>
                    nav.navigate('H2H', { homeIso: f.homeFlag, awayIso: f.awayFlag })
                  }
                >
                  <Text style={{ color: '#FFD700' }}>⚔️ H2H Compare</Text>
                </Pressable>
              </View>

              {isOpen && (
                <View
                  style={{
                    marginTop: 8,
                    backgroundColor: '#0E213B',
                    padding: 10,
                    borderRadius: 8,
                  }}
                >
                  <Text style={{ color: '#9FB2CF' }}>
                    AI factors in form, squad strength and competition context to reach this view.
                  </Text>
                </View>
              )}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}
