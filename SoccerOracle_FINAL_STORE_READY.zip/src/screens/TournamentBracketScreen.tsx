import React from 'react';
import { View, Text, ScrollView, Pressable } from 'react-native';
import { EURO_2025_BRACKET } from '../data/tournaments.mock';
import { useNavigation } from '@react-navigation/native';

export default function TournamentBracketScreen() {
  const nav: any = useNavigation();
  const bracket = EURO_2025_BRACKET;
  return (
    <View style={{ backgroundColor: '#0B1727', flex: 1 }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 26, fontWeight: '700', marginBottom: 20 }}>
          {bracket.name} — Tournament Bracket
        </Text>
        {bracket.matches.map((m, i) => (
          <Pressable
            key={i}
            onPress={() => nav.navigate('H2H', { homeIso: m.homeIso, awayIso: m.awayIso })}
            style={{
              backgroundColor: '#102846',
              padding: 14,
              borderRadius: 10,
              marginBottom: 12,
            }}
          >
            <Text style={{ color: '#5AB8FF', fontSize: 14 }}>{m.round}</Text>
            <Text style={{ color: '#fff', marginTop: 6 }}>
              {m.homeIso} vs {m.awayIso}
            </Text>
            <Text style={{ color: '#9FB2CF', fontSize: 12, marginTop: 4 }}>
              {new Date(m.kickoffISO).toUTCString()}
            </Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}
