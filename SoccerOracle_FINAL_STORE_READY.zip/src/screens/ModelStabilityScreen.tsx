import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { MODEL_STABILITY as S } from '../data/modelStability.mock';

export default function ModelStabilityScreen() {
  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: '700', marginBottom: 16 }}>
          Model Stability
        </Text>
        <View
          style={{
            backgroundColor: '#112A45',
            padding: 20,
            borderRadius: 12,
            marginBottom: 20,
          }}
        >
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>
            Stability Score
          </Text>
          <Text style={{ color: '#5AB8FF', fontSize: 40, fontWeight: '800', marginTop: 6 }}>
            {S.stabilityScore}/100
          </Text>
          <Text style={{ color: '#9FB2CF', marginTop: 8 }}>
            Volatility Index: {S.volatilityIndex}
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
