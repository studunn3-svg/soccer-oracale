import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, ActivityIndicator } from 'react-native';
import { EURO_2025_BRACKET } from '../data/tournaments.mock';
import { simulateTournament, TournamentSimulationResult } from '../lib/tournamentSimulator';

export default function TournamentSimulatorScreen() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TournamentSimulationResult | null>(null);

  const onSimulate = async () => {
    setLoading(true);
    try {
      const res = await simulateTournament(EURO_2025_BRACKET);
      setResult(res);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 24, fontWeight: '700', marginBottom: 16 }}>
          AI Tournament Simulator
        </Text>
        <Pressable
          onPress={onSimulate}
          disabled={loading}
          style={{
            backgroundColor: loading ? '#163456' : '#1F5DA1',
            paddingVertical: 12,
            borderRadius: 8,
            alignItems: 'center',
            marginBottom: 20,
          }}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={{ color: '#fff', fontSize: 16, fontWeight: '700' }}>
              Run Simulation
            </Text>
          )}
        </Pressable>

        {result && (
          <>
            <View
              style={{
                backgroundColor: '#112A45',
                padding: 16,
                borderRadius: 12,
                marginBottom: 20,
              }}
            >
              <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>
                Champion (AI Prediction)
              </Text>
              <Text
                style={{
                  color: '#5AB8FF',
                  fontSize: 24,
                  fontWeight: '800',
                  marginTop: 8,
                }}
              >
                {result.championIso}
              </Text>
            </View>

            {result.matches.map((m) => (
              <View
                key={m.id}
                style={{
                  backgroundColor: '#102846',
                  padding: 12,
                  borderRadius: 10,
                  marginBottom: 10,
                }}
              >
                <Text style={{ color: '#5AB8FF', fontSize: 12 }}>{m.round}</Text>
                <Text style={{ color: '#fff', marginTop: 4 }}>
                  {m.homeIso} {m.homeScore} – {m.awayScore} {m.awayIso}
                </Text>
                <Text style={{ color: '#9FB2CF', marginTop: 6 }}>{m.rationale}</Text>
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </View>
  );
}
