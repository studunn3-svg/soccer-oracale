import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { MODEL_VERSION_COMPARISON as DATA } from '../data/modelVersionComparison.mock';

export default function ModelVersionComparisonScreen() {
  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: '700', marginBottom: 20 }}>
          Model Version Comparison
        </Text>

        <Text style={{ color: '#fff', fontSize: 20, fontWeight: '700', marginBottom: 12 }}>
          Global Accuracy Trend
        </Text>

        {DATA.map((v, i) => (
          <View
            key={i}
            style={{
              backgroundColor: '#112A45',
              padding: 16,
              borderRadius: 12,
              marginBottom: 16,
            }}
          >
            <Text style={{ color: '#5AB8FF', fontSize: 14 }}>{v.version}</Text>
            <Text style={{ color: '#fff', fontSize: 32, fontWeight: '800', marginVertical: 8 }}>
              {v.global}%
            </Text>
            <Text style={{ color: '#9FB2CF' }}>
              Avg Confidence Error: {v.avgConfidenceError}%
            </Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
