import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import MenuButton from '../components/MenuButton';

export default function HomeScreen() {
  const nav: any = useNavigation();
  return (
    <View style={{ flex: 1, backgroundColor: '#050B16' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#FFD700', fontSize: 12, fontWeight: '700', marginBottom: 4 }}>
          SOCCER ORACLE
        </Text>
        <Text style={{ color: '#fff', fontSize: 24, fontWeight: '700', marginBottom: 16 }}>
          AI-Powered Football Intelligence
        </Text>
        <Text style={{ color: '#9FB2CF', marginBottom: 16 }}>
          Explore fixtures, international team strength, AI tournament simulations and a full Model Lab
          for tracking accuracy, evolution and stability.
        </Text>

        <MenuButton label="International Fixtures" onPress={() => nav.navigate('InternationalFixtures')} />
        <MenuButton label="Global Power Rankings" onPress={() => nav.navigate('PowerRankings')} />
        <MenuButton label="Tournament Bracket" onPress={() => nav.navigate('TournamentBracket')} />
        <MenuButton label="Tournament Simulator" onPress={() => nav.navigate('TournamentSimulator')} />
        <MenuButton label="Model Accuracy (Lab)" onPress={() => nav.navigate('ModelAccuracy')} />
        <MenuButton label="Model Evolution Log" onPress={() => nav.navigate('ModelEvolution')} />
        <MenuButton label="Version Comparison" onPress={() => nav.navigate('ModelVersionComparison')} />
        <MenuButton label="Accuracy Forecasting" onPress={() => nav.navigate('AccuracyForecast')} />
        <MenuButton label="Model Anatomy" onPress={() => nav.navigate('ModelAnatomy')} />
        <MenuButton label="Model Stability" onPress={() => nav.navigate('ModelStability')} />
        <MenuButton label="ROI Simulator (Hypothetical)" onPress={() => nav.navigate('ROISimulator')} />
        <MenuButton label="Settings" onPress={() => nav.navigate('Settings')} />
        <MenuButton label="Go Premium" onPress={() => nav.navigate('Paywall')} accent />
      </ScrollView>
    </View>
  );
}
