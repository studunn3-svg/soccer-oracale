import React from 'react';
import { View, Text, ScrollView } from 'react-native';

export default function ModelAnatomyScreen() {
  return (
    <View style={{ flex: 1, backgroundColor: '#0B1727' }}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ color: '#fff', fontSize: 28, fontWeight: '700', marginBottom: 16 }}>
          How the Oracle Thinks
        </Text>
        {[
          {
            title: 'Form Index',
            body:
              'Measures recent match results (W/D/L), goal difference and opponent strength to estimate how “hot” or “cold” each team is.',
          },
          {
            title: 'Momentum Index',
            body:
              'Captures trends over time – is a team improving or regressing? Combines recent performance and fitness indicators where available.',
          },
          {
            title: 'Star Power',
            body:
              'Aggregates key player ratings, recent form and availability to judge how much influence top players may have on a match.',
          },
          {
            title: 'Defensive Solidity',
            body:
              'Looks at clean sheets, goals conceded, shots faced and xG against to estimate how hard a team is to break down.',
          },
        ].map((s, i) => (
          <View
            key={i}
            style={{
              backgroundColor: '#112A45',
              padding: 16,
              borderRadius: 12,
              marginBottom: 12,
            }}
          >
            <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>{s.title}</Text>
            <Text style={{ color: '#9FB2CF', marginTop: 8 }}>{s.body}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
