export const MODEL_VERSION_COMPARISON = [
  {
    version: '6.7.0',
    global: 63,
    compAccuracy: {
      premier: 67,
      laliga: 61,
      seriea: 58,
      euroq: 64,
      wcq: 69,
    },
    avgConfidenceError: 14,
  },
  {
    version: '6.9.5-nextgen',
    global: 71,
    compAccuracy: {
      premier: 75,
      laliga: 68,
      seriea: 65,
      euroq: 72,
      wcq: 77,
    },
    avgConfidenceError: 8,
  },
];
