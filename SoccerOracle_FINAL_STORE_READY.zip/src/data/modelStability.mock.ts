export const MODEL_STABILITY = {
  stabilityScore: 86,
  volatilityIndex: 14,
  notes:
    'The model shows smooth, incremental improvements with no extreme jumps. Changes between versions are controlled and well-calibrated.',
  versionVolatility: [
    { version: '6.7.0', deltaAccuracy: 2, deltaError: -1 },
    { version: '6.9.5-nextgen', deltaAccuracy: 3, deltaError: -2 },
  ],
};
