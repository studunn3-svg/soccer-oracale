export type PlayerStats = {
  id: string;
  name: string;
  position: string;
  club: string;
  nationIso: string;
  games: number;
  minutes: number;
  tackles: number;
  yellowCards: number;
  redCards: number;
  goals: number;
  assists: number;
  passCompletion: number;
  rating: number;
  form: string[];
};

export const MOCK_PLAYERS: PlayerStats[] = [
  {
    id: 'harry-kane',
    name: 'Harry Kane',
    position: 'ST',
    club: 'Bayern Munich',
    nationIso: 'ENG',
    games: 10,
    minutes: 870,
    tackles: 5,
    yellowCards: 1,
    redCards: 0,
    goals: 8,
    assists: 3,
    passCompletion: 82,
    rating: 7.9,
    form: ['8.1', '7.6', '7.8', '8.0', '7.9'],
  },
];
