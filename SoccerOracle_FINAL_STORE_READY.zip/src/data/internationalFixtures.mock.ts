export type InternationalFixture = {
  id: string;
  homeTeam: string;
  awayTeam: string;
  homeFlag: string;
  awayFlag: string;
  competition: string;
  competitionName: string;
  kickoffISO: string;
  neutralVenue: boolean;
  venue?: string;
  predictedOutcome?: 'HOME' | 'DRAW' | 'AWAY';
  confidence?: number;
};

export const MOCK_INTERNATIONAL_FIXTURES: InternationalFixture[] = [
  {
    id: 'int-001',
    homeTeam: 'England',
    awayTeam: 'Brazil',
    homeFlag: 'ENG',
    awayFlag: 'BRA',
    competition: 'FRIENDLY',
    competitionName: 'International Friendly',
    kickoffISO: '2025-03-21T19:45:00Z',
    neutralVenue: false,
    venue: 'Wembley Stadium',
    predictedOutcome: 'HOME',
    confidence: 0.62,
  },
  {
    id: 'int-002',
    homeTeam: 'Germany',
    awayTeam: 'Spain',
    homeFlag: 'GER',
    awayFlag: 'ESP',
    competition: 'EURO_QUALIFIER',
    competitionName: 'EURO Qualifier',
    kickoffISO: '2025-03-24T19:45:00Z',
    neutralVenue: false,
    venue: 'Allianz Arena',
    predictedOutcome: 'DRAW',
    confidence: 0.41,
  },
];
