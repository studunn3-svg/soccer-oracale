export type InternationalTeam = {
  id: string;
  name: string;
  iso: string;
  confederation: string;
  fifaRanking: number;
  form: string[];
  goalsFor: number;
  goalsAgainst: number;
  cleanSheets: number;
  manager: string;
  preferredFormation: string;
  starPlayers: { name: string; position: string; club: string; rating: number }[];
  teamStrengthIndex?: number;
};

export const MOCK_TEAMS: InternationalTeam[] = [
  {
    id: 'eng',
    name: 'England',
    iso: 'ENG',
    confederation: 'UEFA',
    fifaRanking: 4,
    form: ['W', 'W', 'D', 'L', 'W'],
    goalsFor: 9,
    goalsAgainst: 4,
    cleanSheets: 2,
    manager: 'Gareth Southgate',
    preferredFormation: '4-3-3',
    starPlayers: [
      { name: 'Harry Kane', position: 'ST', club: 'Bayern Munich', rating: 7.6 },
      { name: 'Jude Bellingham', position: 'CM', club: 'Real Madrid', rating: 8.2 },
    ],
    teamStrengthIndex: 88,
  },
  {
    id: 'bra',
    name: 'Brazil',
    iso: 'BRA',
    confederation: 'CONMEBOL',
    fifaRanking: 3,
    form: ['L', 'D', 'W', 'W', 'D'],
    goalsFor: 7,
    goalsAgainst: 3,
    cleanSheets: 3,
    manager: 'Dorival Júnior',
    preferredFormation: '4-2-3-1',
    starPlayers: [
      { name: 'Neymar Jr', position: 'LW', club: 'Al Hilal', rating: 8.0 },
      { name: 'Vinícius Jr', position: 'LW', club: 'Real Madrid', rating: 8.4 },
    ],
    teamStrengthIndex: 92,
  },
];
