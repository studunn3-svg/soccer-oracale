export const MODEL_ACCURACY_DATA = {
  globalAccuracy: 67,
  last3Days: 64,
  last7Days: 69,
  last30Days: 66,
  byCompetition: [
    { name: 'Premier League', accuracy: 71 },
    { name: 'La Liga', accuracy: 66 },
  ],
  confidenceBuckets: [
    { bucket: '90–100%', accuracy: 78 },
    { bucket: '80–89%', accuracy: 72 },
    { bucket: '70–79%', accuracy: 61 },
  ],
  streaks: {
    longestWinStreak: 9,
    longestLoseStreak: 3,
    currentStreak: 4,
  },
  topCategories: [
    { label: 'Over 2.5 Goals', accuracy: 71 },
    { label: 'Both Teams To Score', accuracy: 69 },
  ],
  worstCategories: [
    { label: 'Correct Score', accuracy: 22 },
  ],
};
