import type { TournamentBracket } from '../lib/tournamentSimulator';

export const EURO_2025_BRACKET: TournamentBracket = {
  name: 'EURO 2025',
  matches: [
    { id: 'm1', round: 'R16', homeIso: 'ENG', awayIso: 'SCO', kickoffISO: '2025-06-20T18:00Z' },
    { id: 'm2', round: 'R16', homeIso: 'ESP', awayIso: 'GER', kickoffISO: '2025-06-20T21:00Z' },
    { id: 'final', round: 'FINAL', homeIso: 'ENG', awayIso: 'GER', kickoffISO: '2025-07-05T20:00Z' },
  ],
};
