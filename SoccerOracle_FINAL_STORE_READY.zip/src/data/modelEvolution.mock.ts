export const MODEL_EVOLUTION_LOG = [
  {
    version: '6.7.0',
    date: '2025-01-12',
    improvements: [
      'New prediction confidence engine',
      'Improved player card projection model',
    ],
    accuracyBefore: 61,
    accuracyAfter: 63,
    speedImprovement: '+12%',
    notes: 'First major stabilisation of the model for international fixtures.',
  },
  {
    version: '6.9.5-nextgen',
    date: '2025-03-10',
    improvements: [
      'AI Head-to-Head Engine',
      'International Team Pages',
      'Global Power Rankings',
      'Model Accuracy Dashboard',
    ],
    accuracyBefore: 68,
    accuracyAfter: 71,
    speedImprovement: '+18%',
    notes: 'Massive next-gen upgrade unlocking full international ecosystem.',
  },
];
