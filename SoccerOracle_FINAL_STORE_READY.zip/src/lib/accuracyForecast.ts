import { MODEL_VERSION_COMPARISON as DATA } from '../data/modelVersionComparison.mock';

export type ForecastPoint = {
  versionName: string;
  predictedAccuracy: number;
  predictedConfidenceError: number;
};

export function forecastNextAccuracy(steps = 3): ForecastPoint[] {
  const accuracies = DATA.map((v) => v.global);
  const errors = DATA.map((v) => v.avgConfidenceError);
  const xs = accuracies.map((_, i) => i);

  const linReg = (xArr: number[], yArr: number[]) => {
    const n = xArr.length;
    const sumX = xArr.reduce((a, b) => a + b, 0);
    const sumY = yArr.reduce((a, b) => a + b, 0);
    const sumXY = xArr.reduce((a, b, i) => a + b * yArr[i], 0);
    const sumX2 = xArr.reduce((a, b) => a + b * b, 0);
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;
    return { slope, intercept };
  };

  const accReg = linReg(xs, accuracies);
  const errReg = linReg(xs, errors);
  const lastIndex = xs[xs.length - 1];

  const output: ForecastPoint[] = [];
  for (let i = 1; i <= steps; i++) {
    const newX = lastIndex + i;
    output.push({
      versionName: `vNext+${i}`,
      predictedAccuracy: Math.round(accReg.slope * newX + accReg.intercept),
      predictedConfidenceError: Math.round(errReg.slope * newX + errReg.intercept),
    });
  }
  return output;
}
