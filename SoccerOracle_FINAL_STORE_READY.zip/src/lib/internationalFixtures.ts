import { MOCK_INTERNATIONAL_FIXTURES, InternationalFixture } from '../data/internationalFixtures.mock';

export async function getInternationalFixtures(): Promise<InternationalFixture[]> {
  return MOCK_INTERNATIONAL_FIXTURES;
}
