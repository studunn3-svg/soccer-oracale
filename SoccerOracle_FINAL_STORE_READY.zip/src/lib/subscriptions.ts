// Placeholder subscriptions helper.
// This is wired for future RevenueCat integration but currently runs in mock mode.

export type Plan = {
  id: string;
  name: string;
  price: string;
  period: 'MONTHLY' | 'YEARLY';
  highlight?: string;
};

export const PLANS: Plan[] = [
  {
    id: 'soccer_oracle_premium_monthly',
    name: 'Soccer Oracle Premium — Monthly',
    price: '£4.99',
    period: 'MONTHLY',
    highlight: 'Best to try everything',
  },
  {
    id: 'soccer_oracle_premium_yearly',
    name: 'Soccer Oracle Premium — Yearly',
    price: '£39.99',
    period: 'YEARLY',
    highlight: 'Save over 30%',
  },
];

// In a real build this would call RevenueCat Purchases API.
// For now, we just simulate success.

export async function purchasePlan(planId: string): Promise<{ success: boolean }> {
  console.log('Mock purchase for plan:', planId);
  return { success: true };
}

export async function restorePurchases(): Promise<{ success: boolean }> {
  console.log('Mock restore purchases');
  return { success: true };
}
