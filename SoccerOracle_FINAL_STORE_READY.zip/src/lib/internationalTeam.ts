import { MOCK_TEAMS, InternationalTeam } from '../data/internationalTeams.mock';

export async function getTeamProfile(iso: string): Promise<InternationalTeam> {
  const found = MOCK_TEAMS.find((t) => t.iso === iso);
  return found || MOCK_TEAMS[0];
}
