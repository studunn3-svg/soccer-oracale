import { getTeamProfile } from './internationalTeam';

export type H2HOutput = {
  scoreHome: number;
  scoreAway: number;
  confidenceGap: number;
  reasons: string[];
};

function avg(arr: number[]): number {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

export async function computeH2H(homeIso: string, awayIso: string): Promise<H2HOutput> {
  const home = await getTeamProfile(homeIso);
  const away = await getTeamProfile(awayIso);

  const baseHome = home.teamStrengthIndex ?? 50;
  const baseAway = away.teamStrengthIndex ?? 50;

  const formValue = (f: string) => (f === 'W' ? 3 : f === 'D' ? 1 : 0);
  const formHome = avg(home.form.map(formValue));
  const formAway = avg(away.form.map(formValue));

  const rankHome = 200 - home.fifaRanking;
  const rankAway = 200 - away.fifaRanking;

  const gdHome = home.goalsFor - home.goalsAgainst;
  const gdAway = away.goalsFor - away.goalsAgainst;

  const starsHome = avg(home.starPlayers.map((p) => p.rating));
  const starsAway = avg(away.starPlayers.map((p) => p.rating));

  const scoreHome =
    baseHome * 0.45 + formHome * 5 + rankHome * 0.15 + gdHome * 2 + starsHome * 3;
  const scoreAway =
    baseAway * 0.45 + formAway * 5 + rankAway * 0.15 + gdAway * 2 + starsAway * 3;

  const diff = Math.abs(scoreHome - scoreAway);
  const reasons = [
    `Team strength difference: ${Math.round(baseHome)} vs ${Math.round(baseAway)}`,
    `Recent form: ${home.form.join('')} vs ${away.form.join('')}`,
    `FIFA ranking: ${home.fifaRanking} vs ${away.fifaRanking}`,
    `Star influence: ${starsHome.toFixed(1)} vs ${starsAway.toFixed(1)}`,
    `Goals differential: ${gdHome} vs ${gdAway}`,
  ];

  return {
    scoreHome: Math.round(scoreHome),
    scoreAway: Math.round(scoreAway),
    confidenceGap: Math.round(diff),
    reasons,
  };
}
