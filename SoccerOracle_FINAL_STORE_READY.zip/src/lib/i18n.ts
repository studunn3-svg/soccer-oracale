
import * as Localization from 'expo-localization';
import { I18n } from 'i18n-js';

import enUS from '../locales/en-US.json';
import enGB from '../locales/en-GB.json';
import esES from '../locales/es-ES.json';
import frFR from '../locales/fr-FR.json';
import deDE from '../locales/de-DE.json';
import itIT from '../locales/it-IT.json';

const translations = {
  'en-US': enUS,
  'en-GB': enGB,
  'es-ES': esES,
  'fr-FR': frFR,
  'de-DE': deDE,
  'it-IT': itIT
};

const i18n = new I18n(translations);

i18n.enableFallback = true;
i18n.defaultLocale = 'en-US';
i18n.locale = Localization.locale || 'en-US';

export default i18n;
