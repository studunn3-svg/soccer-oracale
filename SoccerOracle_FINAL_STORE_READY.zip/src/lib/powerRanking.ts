import { MOCK_TEAMS } from '../data/internationalTeams.mock';

export type RankedNation = {
  iso: string;
  name: string;
  score: number;
  confed: string;
  trend: 'UP' | 'DOWN' | 'SAME';
};

function scoreTeam(t: any): number {
  const formValue = (f: string) => (f === 'W' ? 3 : f === 'D' ? 1 : 0);
  const formScore = t.form.map(formValue).reduce((a: number, b: number) => a + b, 0);
  const starScore =
    t.starPlayers.reduce((a: number, p: any) => a + p.rating, 0) / t.starPlayers.length;
  const base = t.teamStrengthIndex ?? 50;
  return base * 0.6 + formScore * 3 + starScore * 4 + (200 - t.fifaRanking) * 0.2;
}

export async function computeGlobalPowerRanking(): Promise<RankedNation[]> {
  const teams = MOCK_TEAMS;
  const ranked: RankedNation[] = teams.map((t) => ({
    iso: t.iso,
    name: t.name,
    confed: t.confederation,
    score: Math.round(scoreTeam(t)),
    trend: 'SAME',
  }));
  return ranked.sort((a, b) => b.score - a.score);
}
