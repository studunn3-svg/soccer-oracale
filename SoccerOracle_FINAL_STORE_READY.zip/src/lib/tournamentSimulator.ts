export type TournamentMatch = {
  id: string;
  round: 'R16' | 'QF' | 'SF' | 'FINAL';
  homeIso: string;
  awayIso: string;
  kickoffISO: string;
};

export type TournamentBracket = {
  name: string;
  matches: TournamentMatch[];
};

import { computeH2H } from './h2h';

export type SimulatedMatch = TournamentMatch & {
  winnerIso: string;
  loserIso: string;
  homeScore: number;
  awayScore: number;
  rationale: string;
};

export type TournamentSimulationResult = {
  bracketName: string;
  championIso: string;
  matches: SimulatedMatch[];
};

function randomScoreFromDiff(diff: number): [number, number] {
  if (diff < 15) return [2, 1];
  if (diff < 30) return [3, 1];
  return [3, 0];
}

export async function simulateTournament(bracket: TournamentBracket): Promise<TournamentSimulationResult> {
  const matches: SimulatedMatch[] = [];
  for (const m of bracket.matches) {
    const h2h = await computeH2H(m.homeIso, m.awayIso);
    const homeFavoured = h2h.scoreHome >= h2h.scoreAway;
    const diff = Math.abs(h2h.scoreHome - h2h.scoreAway);
    const base = randomScoreFromDiff(diff);
    const [homeScore, awayScore] = homeFavoured ? base : ([base[1], base[0]] as [number, number]);
    const winnerIso = homeFavoured ? m.homeIso : m.awayIso;
    const loserIso = homeFavoured ? m.awayIso : m.homeIso;
    matches.push({
      ...m,
      winnerIso,
      loserIso,
      homeScore,
      awayScore,
      rationale: `AI favours ${winnerIso} with H2H scores ${h2h.scoreHome} vs ${h2h.scoreAway} (gap ${h2h.confidenceGap}).`,
    });
  }
  const finalMatch = matches.find((m) => m.round === 'FINAL') || matches[matches.length - 1];
  const championIso = finalMatch.winnerIso;
  return { bracketName: bracket.name, championIso, matches };
}
